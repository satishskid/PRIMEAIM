
import dotenv from 'dotenv';

// Load environment variables from .env file
dotenv.config();

/**
 * Application configuration.
 * It's recommended to use environment variables for sensitive data.
 */
export const config = {
  // Server port
  port: process.env.PORT || 3001,

  // Gemini API Key
  geminiApiKey: process.env.API_KEY,

  // JWT Secret for signing tokens
  jwtSecret: process.env.JWT_SECRET || 'a-secure-secret-for-development-only',
};
