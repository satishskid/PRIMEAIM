
// This file uses declaration merging to add the 'user' property to Express's Request type.
// This is the recommended approach for extending Express types in TypeScript.
// It avoids module-level interface extension issues and makes the custom property
// available on the standard Request type throughout the application.

// FIX: Corrected import path for types.
import { BusinessType } from '../../packages/types/index';

declare global {
  namespace Express {
    export interface Request {
      user?: {
        id: string;
        email: string;
        businessType: BusinessType;
        isAdmin?: boolean;
      };
    }
  }
}

// By using declaration merging, we no longer need to export a custom AuthenticatedRequest interface.
// We can now use the standard `Request` type from 'express' in our middleware and controllers,
// and it will have the optional `user` property.
