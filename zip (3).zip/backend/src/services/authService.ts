import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { config } from '../config';
import { BusinessType } from '../../packages/types';

interface UserPayload {
    id: string;
    email: string;
    businessType: BusinessType;
    isAdmin?: boolean;
}

/**
 * Generates a JWT for a given user payload.
 */
export const generateToken = (payload: UserPayload): string => {
    return jwt.sign(payload, config.jwtSecret, { expiresIn: '1d' }); // Token expires in 1 day
};

/**
 * Verifies a JWT. Returns the decoded payload if valid, otherwise null.
 */
export const verifyToken = (token: string): UserPayload | null => {
    try {
        const decoded = jwt.verify(token, config.jwtSecret);
        return decoded as UserPayload;
    } catch (error) {
        console.error("JWT verification failed:", error);
        return null;
    }
};

/**
 * Hashes a plain-text password.
 */
export const hashPassword = async (password: string): Promise<string> => {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
};

/**
 * Compares a plain-text password with a hashed password.
 */
export const comparePassword = async (password: string, hash: string): Promise<boolean> => {
    return bcrypt.compare(password, hash);
};
