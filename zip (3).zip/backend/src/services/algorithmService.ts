
// FIX: Corrected import path for types.
import { ProviderProfile, AlgorithmFactorWeights } from '../../../packages/types/index';
import { prisma } from './databaseService';

/**
 * This service is a placeholder for the complex algorithms that would power
 * provider matching and ranking in the marketplace.
 */

/**
 * Scores a list of providers based on a set of weights and provider data.
 * This is a conceptual implementation.
 * @param providers - The list of provider profiles to score.
 * @param weights - The current algorithm weights for this provider type.
 */
export const scoreProviders = async (
    providers: ProviderProfile[],
    weights: AlgorithmFactorWeights
): Promise<(ProviderProfile & { score: number; scoreBreakdown: any })[]> => {

    console.log("Algorithm: Scoring providers with weights:", weights);

    const scoredProviders = providers.map(provider => {
        // These values would be fetched from the DB or calculated in real-time
        const mockData = {
            priceScore: Math.random() * 10, // Lower price = higher score
            speedScore: Math.random() * 10, // Faster delivery/service = higher score
            qualityScore: Math.random() * 10, // Higher patient ratings = higher score
            patientPreference: Math.random() * 0.2 // Small bonus for past user interactions
        };

        const score = 
            (mockData.priceScore * weights.priceWeight) +
            (mockData.speedScore * weights.speedWeight) +
            (mockData.qualityScore * weights.qualityWeight);
        
        const finalScore = score * (1 + weights.patientPreferenceImpact * mockData.patientPreference);

        return {
            ...provider,
            score: parseFloat(finalScore.toFixed(2)),
            scoreBreakdown: {
                price: parseFloat(mockData.priceScore.toFixed(2)),
                speed: parseFloat(mockData.speedScore.toFixed(2)),
                quality: parseFloat(mockData.qualityScore.toFixed(2)),
                final: parseFloat(finalScore.toFixed(2)),
            }
        };
    });

    return scoredProviders.sort((a, b) => b.score - a.score);
};

/**
 * Gets the current algorithm weights from the database.
 */
export const getAlgorithmFactors = async (): Promise<any> => {
    const config = await prisma.algorithmConfig.findUnique({
        where: { id: 'singleton' }
    });
    if (!config) {
        throw new Error("Algorithm configuration not found.");
    }
    return {
        pharmacy: {
            priceWeight: config.pharmacyPriceWeight,
            speedWeight: config.pharmacySpeedWeight,
            qualityWeight: config.pharmacyQualityWeight,
            patientPreferenceImpact: config.pharmacyPatientPreferenceImpact,
        },
        lab: {
            priceWeight: config.labPriceWeight,
            speedWeight: config.labSpeedWeight,
            qualityWeight: config.labQualityWeight,
            patientPreferenceImpact: config.labPatientPreferenceImpact,
        }
    };
};