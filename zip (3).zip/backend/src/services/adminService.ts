import { prisma } from './databaseService';
import { MarketplaceApplication, AdminDashboardData, UserStatus, BusinessType, MarketplaceApplicationStatus, AlgorithmFactorWeights } from '../../packages/types';
import { createMarketplaceApplication } from './marketplaceService';

export const createApplication = async (applicationData: MarketplaceApplication): Promise<MarketplaceApplication> => {
    return createMarketplaceApplication(applicationData);
};

export const getAdminDashboardData = async (): Promise<AdminDashboardData> => {
    const applicationCounts = await prisma.marketplaceApplication.groupBy({
        by: ['status'],
        _count: {
            status: true,
        },
    });

    const providerCounts = await prisma.user.groupBy({
        where: { isAdmin: false },
        by: ['businessType'],
        _count: {
            businessType: true,
        },
    });

    const recentApplications = await prisma.marketplaceApplication.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
    });

    const activeUsers = await prisma.user.findMany({
        where: { isActive: true },
        take: 10,
    });
    
    // Format counts
    const formattedAppCounts: Record<MarketplaceApplicationStatus, number> = {
        [MarketplaceApplicationStatus.SUBMITTED]: 0,
        [MarketplaceApplicationStatus.IN_REVIEW]: 0,
        [MarketplaceApplicationStatus.APPROVED]: 0,
        [MarketplaceApplicationStatus.REJECTED]: 0,
    };
    applicationCounts.forEach(c => {
        formattedAppCounts[c.status as MarketplaceApplicationStatus] = c._count.status;
    });

    const formattedProviderCounts: Record<BusinessType, number> = {
        [BusinessType.CLINIC]: 0,
        [BusinessType.LAB]: 0,
        [BusinessType.PHARMACY]: 0,
    };
    providerCounts.forEach(c => {
        formattedProviderCounts[c.businessType as BusinessType] = c._count.businessType;
    });

    return {
        applicationCounts: formattedAppCounts,
        providerCounts: formattedProviderCounts,
        recentApplications: recentApplications as unknown as MarketplaceApplication[],
        activeUsers: activeUsers,
    };
};

export const updateApplicationStatus = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    const updatedApplication = await prisma.marketplaceApplication.update({
        where: { id },
        data: { status },
    });

    if (status === 'APPROVED') {
        // Here you would trigger user creation, profile creation, welcome emails etc.
        console.log(`Application ${id} approved. Triggering user creation...`);
    }

    return updatedApplication;
};

export const updateUserStatus = async (id: string, status: UserStatus) => {
    const updatedUser = await prisma.user.update({
        where: { id },
        data: { 
            status,
            isActive: status === UserStatus.ACTIVE 
        },
    });
    return updatedUser;
};


export const getAlgorithmFactors = async () => {
    return prisma.algorithmConfig.findUnique({
        where: { id: 'singleton' },
    });
};

export const updateAlgorithmFactors = async (type: 'PHARMACY' | 'LAB', factors: Partial<AlgorithmFactorWeights>) => {
    const data: any = {};
    if (type === 'PHARMACY') {
        data.pharmacyPriceWeight = factors.priceWeight;
        data.pharmacySpeedWeight = factors.speedWeight;
        data.pharmacyQualityWeight = factors.qualityWeight;
        data.pharmacyPatientPreferenceImpact = factors.patientPreferenceImpact;
    } else { // LAB
        data.labPriceWeight = factors.priceWeight;
        data.labSpeedWeight = factors.speedWeight;
        data.labQualityWeight = factors.qualityWeight;
        data.labPatientPreferenceImpact = factors.patientPreferenceImpact;
    }

    return prisma.algorithmConfig.update({
        where: { id: 'singleton' },
        data,
    });
};
