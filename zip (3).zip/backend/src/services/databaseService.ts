
// FIX: Use require to work around potential module resolution issues with Prisma.
const { PrismaClient } = require('@prisma/client');

// Instantiate PrismaClient
const prisma = new PrismaClient({
    log: ['query', 'info', 'warn', 'error'], // Optional: configure logging
});

// Export the prisma instance so it can be used in other files
export { prisma };