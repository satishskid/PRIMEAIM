/**
 * This is a placeholder for a real email service.
 * In a production environment, you would use a service like Nodemailer,
 * SendGrid, AWS SES, etc., to send transactional emails.
 */

interface EmailOptions {
    to: string;
    subject: string;
    text: string;
    html: string;
}

/**
 * A mock function to "send" an email.
 * @param options - The details of the email to be sent.
 */
export const sendEmail = async (options: EmailOptions): Promise<{ success: boolean; message: string }> => {
    console.log('--- MOCK EMAIL SERVICE ---');
    console.log(`Sending email to: ${options.to}`);
    console.log(`Subject: ${options.subject}`);
    console.log('Body (text):', options.text);
    console.log('--- END MOCK EMAIL ---');
    
    // Simulate an async operation
    await new Promise(resolve => setTimeout(resolve, 500));

    // In a real service, you would handle potential errors from the email provider.
    return { success: true, message: `Email successfully sent to ${options.to}` };
};

/**
 * Example of a specific email template function.
 */
export const sendWelcomeEmail = async (email: string, name: string) => {
    return sendEmail({
        to: email,
        subject: 'Welcome to the Primary Care Assistant Network!',
        text: `Hello ${name},\n\nWelcome aboard! Your application has been approved, and your account is now active.\n\nBest,\nThe PCA Team`,
        html: `<p>Hello ${name},</p><p>Welcome aboard! Your application has been approved, and your account is now active.</p><p>Best,<br/>The PCA Team</p>`,
    });
};
