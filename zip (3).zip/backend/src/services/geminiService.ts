

import { GoogleGenAI } from "@google/genai";
// FIX: Corrected import path for config.
import { config } from '../config/index';

if (!config.geminiApiKey) {
  throw new Error("CRITICAL ERROR: API_KEY for Gemini is not set. AI service will not function.");
}
// FIX: Initialize GoogleGenAI with a named apiKey parameter.
const ai = new GoogleGenAI({ apiKey: config.geminiApiKey });
// FIX: Use recommended model 'gemini-2.5-flash'
const modelName = 'gemini-2.5-flash';

/**
 * A generic helper function for the backend to generate plain text.
 */
export const generateText = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
    });
    // FIX: Access the 'text' property directly from the response object.
    return response.text;
  } catch (error) {
    console.error("Error generating text from Gemini:", error);
    throw new Error("Failed to generate text from AI service.");
  }
};

/**
 * A generic helper function for the backend to generate a JSON response.
 */
export const generateJson = async <T>(prompt: string): Promise<T | null> => {
    try {
        const response = await ai.models.generateContent({
            model: modelName,
            contents: prompt,
            config: {
                responseMimeType: 'application/json'
            }
        });
        // FIX: Access the 'text' property directly from the response object.
        const text = response.text;
        try {
            return JSON.parse(text) as T;
        } catch (parseError) {
             console.error("Failed to parse JSON from Gemini response:", parseError, "Original text:", text);
             return null;
        }
    } catch (error) {
        console.error("Error generating JSON from Gemini:", error);
        return null;
    }
};