
// FIX: Corrected import path for types.
import { MarketplaceApplication, ProviderProfile, BusinessType, ErrorResponse, MarketplaceApplicationStatus, SystemCalculatedRating, PatientFeedbackSummary, LocationDetails, PharmacyProvider } from '../../packages/types'; 
import { prisma } from './databaseService';

/**
 * Creates a new marketplace application in the database.
 */
export const createMarketplaceApplication = async (
  applicationData: MarketplaceApplication
): Promise<MarketplaceApplication> => {
  console.log('marketplaceService: Creating application for', applicationData.businessName);
  
  const newApplication = await prisma.marketplaceApplication.create({
    data: {
      businessName: applicationData.businessName,
      businessType: applicationData.businessType,
      address: applicationData.address,
      contactEmail: applicationData.contactEmail,
      contactPhone: applicationData.contactPhone,
      website: applicationData.website,
      regulatoryComplianceNotes: applicationData.regulatoryComplianceNotes,
      attestedCompliance: applicationData.attestedCompliance,
      pricingTier: applicationData.pricingTier,
      rateListNotes: applicationData.rateListNotes,
      promotionalMessage: applicationData.promotionalMessage,
      operationalHoursNotes: applicationData.operationalHoursNotes,
      communicationChannelNotes: applicationData.communicationChannelNotes,
      keyAccreditationsNotes: applicationData.keyAccreditationsNotes,
      clinicSpecialties: applicationData.clinicSpecialties,
      doctorCount: applicationData.doctorCount,
      bookingSystemNotes: applicationData.bookingSystemNotes,
      specialEquipmentNotes: applicationData.specialEquipmentNotes,
      labTestTypes: applicationData.labTestTypes,
      labCertificationsNotes: applicationData.labCertificationsNotes,
      homeSampleCollectionNotes: applicationData.homeSampleCollectionNotes,
      pharmacyServices: applicationData.pharmacyServices,
      prescriptionDelivery: applicationData.prescriptionDelivery,
      deliveryOptionsNotes: applicationData.deliveryOptionsNotes,
    }
  });

  // The returned object from Prisma might need to be cast or mapped if its type differs from our internal `MarketplaceApplication` type
  return newApplication as unknown as MarketplaceApplication;
};

/**
 * Fetches a provider's profile by their user ID.
 */
export const getProviderProfileById = async (userId: string): Promise<ProviderProfile | null> => {
  console.log('marketplaceService: Fetching provider profile for user ID', userId);
  
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
        pharmacyProfile: true,
        labProfile: true,
        clinicProfile: true,
    }
  });

  if (!user) return null;

  // Return the specific profile that is not null
  const profile = user.pharmacyProfile || user.labProfile || user.clinicProfile;
  if (!profile) return null;

  // Here you would map the Prisma profile object to your rich ProviderProfile type
  // This might involve fetching additional data like reviews, ratings etc.
  
  return {
    ...profile,
    name: user.businessName,
    // Map other shared fields...
  } as unknown as ProviderProfile;
};

/**
 * Lists providers of a specific type (e.g., all active pharmacies).
 */
export const listProvidersByType = async (type: BusinessType, filters?: any): Promise<ProviderProfile[]> => {
  console.log(`marketplaceService: Listing providers of type ${type} with filters`, filters);
  
  if (type === BusinessType.PHARMACY) {
    const pharmacyProfiles = await prisma.pharmacyProviderProfile.findMany({
        where: { user: { isActive: true } }, // Example of filtering
        include: { user: true }
    });
    // Map the result to the rich ProviderProfile type
    return pharmacyProfiles.map(p => ({
        ...p,
        name: p.user.businessName,
        businessType: BusinessType.PHARMACY
        // ... map other fields
    })) as unknown as ProviderProfile[];
  }
  // Add similar logic for LAB and CLINIC
  if (type === BusinessType.LAB) {
     const labProfiles = await prisma.labProviderProfile.findMany({
        where: { user: { isActive: true } },
        include: { user: true }
    });
    return labProfiles.map(p => ({
        ...p,
        name: p.user.businessName,
        businessType: BusinessType.LAB
    })) as unknown as ProviderProfile[];
  }
   if (type === BusinessType.CLINIC) {
     const clinicProfiles = await prisma.clinicProviderProfile.findMany({
        where: { user: { isActive: true } },
        include: { user: true }
    });
    return clinicProfiles.map(p => ({
        ...p,
        name: p.user.businessName,
        businessType: BusinessType.CLINIC
    })) as unknown as ProviderProfile[];
  }
  
  console.warn(`marketplaceService: listProvidersByType for ${type} is a stub and will return empty array.`);
  return [];
};


/**
 * Conceptual: Calculates a system rating for a provider.
 * This would involve complex logic based on verified credentials, operational capabilities,
 * patient feedback, SLA adherence, etc.
 */
export const calculateProviderSystemRating = async (
    providerId: string,
    application: MarketplaceApplication,
    feedbackSummary?: PatientFeedbackSummary
): Promise<SystemCalculatedRating> => {
    // This logic remains conceptual, but would fetch data from the DB to work
    console.log(`marketplaceService: Calculating system rating for ${providerId}`);
    let score = 7.0;
    // ... same logic as before ...
    return {
        score: parseFloat(score.toFixed(1)),
        rationale: "Assessment based on profile and feedback.",
        lastCalculated: new Date().toISOString(),
    };
};