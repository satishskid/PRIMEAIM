// FIX: Add imports for Request and Response from express.
import { Request, Response } from 'express';
import * as geminiService from '../services/geminiService';

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const generateFullPrescription = async (req: Request, res: Response) => {
    const { condition, summary, doctorName, clinicAddress, clinicLicense } = req.body;
    try {
        const prompt = `
            Act as a medical scribe. Based on the following information, generate a formal prescription and patient-friendly educational content.
            
            Diagnosis: ${condition}
            Doctor's Plan: "${summary}"
            
            Prescribing Doctor: ${doctorName}
            Clinic Address: ${clinicAddress}
            Clinic License: ${clinicLicense}
            
            Structure the output as a JSON object with the following schema:
            {
                "medications": [{ "name": string, "dosage": string, "instructions": string, "education": string, "adherenceTips": string }],
                "tests": [{ "name": string, "reason": string, "education": string }],
                "generalAdvice": string
            }
            
            For 'education', explain what the medication/test is for in simple terms.
            For 'adherenceTips', provide a practical tip for remembering to take the medication.
            'generalAdvice' should include lifestyle or non-pharmacological advice from the plan.
            Ensure the output is only the JSON object.`;
            
        const result = await geminiService.generateJson(prompt);
        res.status(200).json(result);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to generate prescription', message: error.message });
    }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const generateKeywords = async (req: Request, res: Response) => {
    const { provisionalDiagnosis, currentSummary } = req.body;
    try {
        const prompt = `
            Given a diagnosis of "${provisionalDiagnosis}" and a doctor's partial plan "${currentSummary}", suggest 3-4 short, relevant keywords or phrases to complete the prescription. Examples: "rest", "hydration", "follow up in 3 days", "avoid strenuous activity".
            Return a JSON array of strings. Example: ["plenty of fluids", "monitor temperature"].
            Only return the JSON array.`;

        const result = await geminiService.generateJson(prompt);
        res.status(200).json(result);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to generate keywords', message: error.message });
    }
};
