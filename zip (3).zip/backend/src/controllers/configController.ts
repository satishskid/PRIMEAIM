
import { Request, Response } from 'express';
// FIX: Corrected import path for config.
import { config } from '../config/index';

/**
 * Exposes non-sensitive configuration to the frontend if needed.
 * Currently not in use.
 */
// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const getPublicConfig = (req: Request, res: Response) => {
    try {
        // Only return configuration that is safe to be exposed publicly.
        const publicConfig = {
            // Example: serviceName: 'Primary Care Assistant'
        };
        res.status(200).json(publicConfig);
    } catch (error: any) {
        res.status(500).json({ error: "Internal Server Error", message: error.message });
    }
};