
import { Request, Response } from 'express';
import * as geminiService from '../services/geminiService';
// FIX: Corrected import path for types.
import { ChatMessage, PatientProfile } from '../../../packages/types/index';

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const getInitialAssessment = async (req: Request, res: Response) => {
    const { symptoms, history, profile } = req.body;
    try {
        const profileInfo = profile ? `Patient Profile: Age ${profile.age}, History: ${profile.pastHistory}, Habits: ${profile.habits}.` : 'No patient profile provided.';
        const historyInfo = history.map(h => `${h.sender}: ${h.text}`).join('\n');
        
        const prompt = `
            A patient presents with the following symptoms: "${symptoms}".
            ${profileInfo}
            Conversation history:
            ${historyInfo}
            
            Based on this, generate a single, crucial follow-up question to clarify the symptoms. The question should be empathetic and easy for a layperson to understand. Also, provide up to 3 meta-symptom questions (e.g., "How would you describe the pain?") with 3-4 short, one-word options each. Determine if this is the final step.
            
            Return a JSON object with this structure: 
            {
                "question": "The main follow-up question.",
                "metaSymptomQuestions": [ { "prompt": "Meta question 1", "options": ["Option1", "Option2"] } ],
                "isFinal": false
            }`;
            
        const result = await geminiService.generateJson(prompt);
        res.status(200).json(result);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to get initial assessment', message: error.message });
    }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const getProvisionalDiagnosis = async (req: Request, res: Response) => {
    const { history, profile } = req.body;
    try {
        const conversation = history.map(h => `${h.sender}: ${h.text}`).join('\n');
        const profileInfo = profile ? `Patient Profile: Age ${profile.age}, History: ${profile.pastHistory}, Habits: ${profile.habits}.` : '';

        const prompt = `
            Analyze the following patient conversation and profile to provide a provisional diagnosis.
            Conversation:
            ${conversation}
            ${profileInfo}
            
            Based on the entire context, provide the most likely condition and a brief, simple explanation (max 2-3 sentences).
            Return a JSON object with this structure:
            {
                "condition": "Likely Condition Name",
                "explanation": "Simple explanation."
            }`;
            
        const result = await geminiService.generateJson(prompt);
        res.status(200).json(result);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to get provisional diagnosis', message: error.message });
    }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const generateDoctorNotes = async (req: Request, res: Response) => {
    const { symptoms, provisionalDiagnosis, profile } = req.body;
    try {
        const profileInfo = profile ? `
            - Age: ${profile.age || 'N/A'}
            - Past Medical History: ${profile.pastHistory || 'N/A'}
            - Lifestyle Habits: ${profile.habits || 'N/A'}
        ` : '';

        const prompt = `
            Generate clinical notes in SOAP format for a patient encounter.
            
            Chief Complaint: ${symptoms}
            Provisional Diagnosis: ${provisionalDiagnosis}
            Patient Background:
            ${profileInfo}
            
            Create a concise summary.
            S: (Subjective) Patient's description of symptoms.
            O: (Objective) Assume normal vitals unless otherwise specified. Note key objective findings implied by the symptoms.
            A: (Assessment) Restate the provisional diagnosis.
            P: (Plan) Suggest initial steps, like advising rest, hydration, and follow-up.
            
            Do not include any introductory or concluding text, just the notes.`;

        const notes = await geminiService.generateText(prompt);
        res.status(200).send(notes);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to generate doctor notes', message: error.message });
    }
};