
import { Request, Response } from 'express';
import { prisma } from '../services/databaseService';
import { generateToken, hashPassword, comparePassword } from '../services/authService';
import { BusinessType } from '../../packages/types';

/**
 * Handles user/provider registration.
 */
// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const register = async (req: Request, res: Response) => {
    const { email, password, businessName, businessType } = req.body;

    if (!email || !password || !businessName || !businessType) {
        return res.status(400).json({ error: 'All fields are required for registration.' });
    }

    try {
        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            return res.status(409).json({ error: 'User with this email already exists.' });
        }

        const hashedPassword = await hashPassword(password);
        
        const newUser = await prisma.user.create({
            data: {
                email,
                password: hashedPassword,
                businessName,
                businessType,
                // Other fields like isActive, status can be set to defaults
            },
        });

        // In a real app, you might not log the user in immediately.
        // For this demo, we'll generate a token.
        const token = generateToken({ 
            id: newUser.id, 
            email: newUser.email, 
            businessType: newUser.businessType as BusinessType,
            isAdmin: newUser.isAdmin,
        });

        res.status(201).json({ 
            message: 'User registered successfully.',
            token,
            user: { id: newUser.id, email: newUser.email, businessName: newUser.businessName }
        });

    } catch (error: any) {
        console.error("Registration error:", error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

/**
 * Handles user/provider login.
 */
// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const login = async (req: Request, res: Response) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
    }

    try {
        const user = await prisma.user.findUnique({ where: { email } });
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials.' });
        }

        const isMatch = await comparePassword(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ error: 'Invalid credentials.' });
        }

        if (!user.isActive) {
            return res.status(403).json({ error: 'Account is not active. Please contact support.' });
        }

        const token = generateToken({
            id: user.id,
            email: user.email,
            businessType: user.businessType as BusinessType,
            isAdmin: user.isAdmin,
        });

        res.status(200).json({
            message: 'Login successful.',
            token,
            user: { id: user.id, email: user.email, businessName: user.businessName, isAdmin: user.isAdmin }
        });

    } catch (error: any) {
        console.error("Login error:", error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};