// FIX: Add import for express types to resolve controller errors.
import { Request, Response } from 'express';
// FIX: Corrected import path for adminService
import * as adminService from '../services/adminService';
// FIX: Corrected import path for types.
import { UserStatus } from '../../packages/types/index';

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const handleGetDashboardData = async (req: Request, res: Response) => {
    try {
        console.log("Admin controller: handling request for dashboard data.");
        const dashboardData = await adminService.getAdminDashboardData();
        res.status(200).json(dashboardData);
    } catch (error: any) {
        console.error("Error in handleGetDashboardData:", error);
        res.status(500).json({ error: "Internal Server Error", message: error.message });
    }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const handleUpdateApplicationStatus = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        if (!id || !status) {
            return res.status(400).json({ error: "Application ID and status are required." });
        }
        if (status !== 'APPROVED' && status !== 'REJECTED') {
            return res.status(400).json({ error: "Invalid status provided." });
        }
        
        const result = await adminService.updateApplicationStatus(id, status);
        res.status(200).json({ message: `Application ${id} has been ${status.toLowerCase()}.`, data: result });

    } catch (error: any) {
        console.error("Error in handleUpdateApplicationStatus:", error);
        res.status(500).json({ error: "Internal Server Error", message: error.message });
    }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const handleUpdateUserStatus = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!id || !status) {
            return res.status(400).json({ error: "User ID and status are required." });
        }

        // Add validation for status enum
        if (!Object.values(UserStatus).includes(status)) {
            return res.status(400).json({ error: "Invalid user status provided." });
        }

        const updatedUser = await adminService.updateUserStatus(id, status);
        res.status(200).json({ message: `User ${id} status updated to ${status}.`, user: updatedUser });

    } catch (error: any) {
        console.error("Error in handleUpdateUserStatus:", error);
        res.status(500).json({ error: "Internal Server Error", message: error.message });
    }
};


// --- Algorithm Config Controllers ---

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const handleGetAlgorithmFactors = async (req: Request, res: Response) => {
  try {
    const factors = await adminService.getAlgorithmFactors();
    res.status(200).json(factors);
  } catch (error: any) {
    console.error("Error in handleGetAlgorithmFactors:", error);
    res.status(500).json({ error: "Internal Server Error", message: error.message });
  }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const handleUpdateAlgorithmFactors = async (req: Request, res: Response) => {
  try {
    const { type, factors } = req.body;

    // Basic validation
    if (!type || !factors) {
        return res.status(400).json({ error: "Validation Error", message: "Type and factors are required."});
    }
    const { priceWeight, speedWeight, qualityWeight, patientPreferenceImpact } = factors;
    if (priceWeight == null || speedWeight == null || qualityWeight == null || patientPreferenceImpact == null) {
        return res.status(400).json({ error: "Validation Error", message: "All factor weights must be provided." });
    }
    const totalWeight = priceWeight + speedWeight + qualityWeight;
    if (Math.abs(totalWeight - 1.0) > 0.01) {
        return res.status(400).json({ error: "Validation Error", message: "The sum of price, speed, and quality weights must be approximately 1.0." });
    }

    if (type === 'PHARMACY' || type === 'LAB') {
        const updatedFactors = await adminService.updateAlgorithmFactors(type, factors);
        res.status(200).json({ success: true, updatedFactors });
    } else {
        return res.status(400).json({ error: "Validation Error", message: "Invalid type specified. Must be PHARMACY or LAB."});
    }

  } catch (error: any) {
    console.error("Error in handleUpdateAlgorithmFactors:", error);
    res.status(500).json({ error: "Internal Server Error", message: error.message });
  }
};
