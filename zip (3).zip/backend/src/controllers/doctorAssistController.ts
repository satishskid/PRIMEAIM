// FIX: Add imports for Request and Response from express.
import { Request, Response } from 'express';
import * as geminiService from '../services/geminiService';
// FIX: Corrected import path for types.
import { PatientProfile } from '../../../packages/types/index';

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const ddx = async (req: Request, res: Response) => {
    const { symptoms, provisionalDiagnosis, notes, profile } = req.body;
    try {
        const profileInfo = profile ? `Patient Profile: Age ${profile.age}, History: ${profile.pastHistory}.` : '';

        const prompt = `
            A patient presents with: "${symptoms}".
            The current provisional diagnosis is: "${provisionalDiagnosis}".
            Clinical notes: "${notes}".
            ${profileInfo}

            Generate a list of 3-4 differential diagnoses (DDx). For each, provide a brief rationale (1 sentence) explaining why it's a possibility.
            
            Return a JSON array with this structure:
            [{ "condition": "Condition Name", "rationale": "Brief rationale." }]
            Only return the JSON array.`;

        const result = await geminiService.generateJson(prompt);
        res.status(200).json(result);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to generate DDx', message: error.message });
    }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const ddxActions = async (req: Request, res: Response) => {
    const { condition, profile } = req.body;
    try {
        const prompt = `
            For a potential diagnosis of "${condition}", suggest the next steps.
            This includes common medications (with typical dosage/instructions) and relevant diagnostic tests.
            
            Return a JSON object with this structure:
            {
                "suggestedMedications": [{ "name": string, "typicalDosage": string, "typicalInstructions": string }],
                "suggestedTests": [{ "name": string, "reason": string }]
            }
            Only return the JSON object.`;
            
        const result = await geminiService.generateJson(prompt);
        res.status(200).json(result);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to suggest actions for DDx', message: error.message });
    }
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const noteSuggestions = async (req: Request, res: Response) => {
    const { currentNotes, provisionalDiagnosis, profile } = req.body;
    try {
        const prompt = `
            Based on the clinical notes so far: "${currentNotes}" for a patient with provisional diagnosis "${provisionalDiagnosis}", suggest 2-3 short, relevant phrases or sentences to add to the notes.
            Categorize each suggestion (e.g., "History", "Plan", "Examination").
            
            Return a JSON array with this structure:
            [{ "type": "Category", "suggestion": "Suggested text." }]
            Only return the JSON array.`;

        const result = await geminiService.generateJson(prompt);
        res.status(200).json(result);
    } catch (error: any) {
        res.status(500).json({ error: 'Failed to generate note suggestions', message: error.message });
    }
};
