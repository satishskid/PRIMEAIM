

import { Request, Response, NextFunction } from 'express';

// This is a conceptual middleware for a "Bring Your Own Key" (BYOK) model.
// It is not used in the primary application flow, which uses a server-side key.
// It would inspect headers for a client-provided API key and validate it.

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const byokMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const apiKey = req.headers['x-api-key'];

    if (!apiKey) {
        return res.status(401).json({ error: 'Unauthorized', message: 'API key is missing.' });
    }

    // In a real BYOK scenario, you would validate the key against a database
    // of customer keys, potentially for rate limiting or access control.
    if (apiKey === 'a-valid-customer-key') {
        // Attach key or customer info to request object if needed
        // (req as any).customer = { id: 'customer-123' };
        next();
    } else {
        return res.status(403).json({ error: 'Forbidden', message: 'Invalid API key.' });
    }
};