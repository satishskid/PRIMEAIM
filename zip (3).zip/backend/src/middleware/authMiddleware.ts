// FIX: Import `Request` from express and remove AuthenticatedRequest.
// The `user` property is added via declaration merging in `src/types.ts`.
import { Request, Response, NextFunction } from 'express';
// FIX: Corrected import path for authService.
import { verifyToken } from '../services/authService';

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const authMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

    if (!token) {
        return res.status(401).json({ error: 'Unauthorized: No token provided.' });
    }

    const payload = verifyToken(token);

    if (!payload) {
        return res.status(403).json({ error: 'Forbidden: Invalid or expired token.' });
    }

    req.user = payload; // Attach user payload to the request object
    next();
};

// FIX: Changed request and response types to the base Express types to resolve property access errors.
export const adminMiddleware = (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !req.user.isAdmin) {
        return res.status(403).json({ error: 'Forbidden: Admin access required.' });
    }
    next();
};