import { Router } from 'express';
import * as doctorAssistController from '../controllers/doctorAssistController';

const router = Router();

router.post('/ddx', doctorAssistController.ddx);
router.post('/ddx-actions', doctorAssistController.ddxActions);
router.post('/note-suggestions', doctorAssistController.noteSuggestions);

export default router;