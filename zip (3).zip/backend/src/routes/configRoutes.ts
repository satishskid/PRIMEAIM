import { Router } from 'express';
import * as configController from '../controllers/configController';

const router = Router();

// This route could be used to provide non-sensitive config data to the frontend.
// It is not actively used in this application.
router.get('/public', configController.getPublicConfig);

export default router;
