import { Router } from 'express';
import * as adminController from '../controllers/adminController';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware';

const router = Router();

// Applying security middleware as per the final release manager's report.
// All admin routes are now protected and require a valid admin JWT.
router.use(authMiddleware);
router.use(adminMiddleware);

router.get('/dashboard', adminController.handleGetDashboardData);
router.put('/applications/:id', adminController.handleUpdateApplicationStatus);
router.put('/users/:id/status', adminController.handleUpdateUserStatus);

router.get('/config/algorithm-factors', adminController.handleGetAlgorithmFactors);
router.put('/config/algorithm-factors', adminController.handleUpdateAlgorithmFactors);

export default router;