import { Router } from 'express';
import * as orderController from '../controllers/orderController';
// import { authMiddleware } from '../middleware/authMiddleware'; // Assuming auth is needed

const router = Router();

// This endpoint would likely be protected to ensure only authenticated users can place orders.
// For now, it's open for the demo.
router.post('/broadcast/pharmacy', orderController.broadcastPharmacyOrder);

// Placeholder for lab orders
// router.post('/broadcast/lab', orderController.broadcastLabOrder);

export default router;
