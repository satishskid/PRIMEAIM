import { Router } from 'express';
import * as symptomCheckerController from '../controllers/symptomCheckerController';

const router = Router();

router.post('/initial-assessment', symptomCheckerController.getInitialAssessment);
router.post('/provisional-diagnosis', symptomCheckerController.getProvisionalDiagnosis);
router.post('/doctor-notes', symptomCheckerController.generateDoctorNotes);

export default router;