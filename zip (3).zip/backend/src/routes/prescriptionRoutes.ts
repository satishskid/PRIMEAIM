import { Router } from 'express';
import * as prescriptionController from '../controllers/prescriptionController';

const router = Router();

router.post('/generate-full', prescriptionController.generateFullPrescription);
router.post('/keywords', prescriptionController.generateKeywords);

export default router;