import { Router } from 'express';
import * as marketplaceController from '../controllers/marketplaceController';

const router = Router();

// Route for listing providers, e.g., /api/marketplace/providers?type=CLINIC
router.get('/providers/:type', marketplaceController.listProviders);
router.get('/providers/pharmacies', marketplaceController.listPharmacies); // more specific route
router.get('/providers/clinics', (req, res) => marketplaceController.listProviders(req, res));


// Route for new provider applications
router.post('/register', marketplaceController.registerProvider);

export default router;
