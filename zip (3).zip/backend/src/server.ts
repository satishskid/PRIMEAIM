import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import http from 'http';
import { config } from './config';
import { initializeWebSocket } from './services/webSocketService';

// Import routes
import symptomCheckerRoutes from './routes/symptomCheckerRoutes';
import prescriptionRoutes from './routes/prescriptionRoutes';
import doctorAssistRoutes from './routes/doctorAssistRoutes';
import marketplaceRoutes from './routes/marketplaceRoutes';
import orderRoutes from './routes/orderRoutes';
import configRoutes from './routes/configRoutes';
import authRoutes from './routes/authRoutes';
import adminRoutes from './routes/adminRoutes';

const app: Express = express();
const server = http.createServer(app);

// Middleware
app.use(cors());
app.use(express.json());

// API Routes
app.get('/api', (req: Request, res: Response) => {
  res.send('Primary Care Assistant API is running.');
});

app.use('/api/symptom-checker', symptomCheckerRoutes);
app.use('/api/prescription', prescriptionRoutes);
app.use('/api/doctor-assist', doctorAssistRoutes);
app.use('/api/marketplace', marketplaceRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/config', configRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);


// Initialize WebSocket server
initializeWebSocket(server);

server.listen(config.port, () => {
  console.log(`[server]: Server is running at http://localhost:${config.port}`);
});

export default app; // For testing purposes