# Primary Care AI Assistant - Backend

This directory contains the Express.js backend server for the Primary Care AI Assistant application. It handles business logic, interacts with the database via Prisma, and securely communicates with the Google Gemini API.

## Getting Started

### Prerequisites

- Node.js (v18 or later)
- npm, pnpm, or yarn
- A running database instance (e.g., PostgreSQL, MySQL, or SQLite for development). See `prisma/schema.prisma` for the connection string setup.

### 1. Installation

Navigate into the `backend` directory and install the dependencies.

```bash
cd backend
npm install
```

### 2. Environment Variables

Create a `.env` file in the `backend` directory by copying the example.

```bash
cp .env.example .env
```

Now, edit the `.env` file and provide the necessary values:

```
# .env

# Your database connection string
DATABASE_URL="file:./dev.db" # Example for SQLite

# Your Google Gemini API Key
API_KEY="your_gemini_api_key_here"

# A secret key for signing JWT tokens
JWT_SECRET="your-super-secret-key-for-dev-change-for-prod"
```

### 3. Prisma Setup

Prisma is used as the ORM to interact with the database.

1.  **Generate Prisma Client:** After any changes to `prisma/schema.prisma`, you need to regenerate the Prisma client.
    ```bash
    npx prisma generate
    ```
2.  **Run Database Migrations:** This command will apply your schema changes to the database, creating tables and columns as needed.
    ```bash
    npx prisma migrate dev --name init
    ```

### 4. Running the Development Server

To run the server with hot-reloading for development:

```bash
npm run dev
```

The server will typically start on `http://localhost:3001`.

### 5. Seed the Database

To populate your database with realistic sample data (including an admin user, providers, and pending applications), run the seed script:

```bash
npx prisma db seed
```

This is essential for testing the application features, especially the Admin Dashboard.

### 6. Production Build

To build the TypeScript code into JavaScript for production:

```bash
npm run build
```

And to run the built application:

```bash
npm start
```

## API Structure

The API endpoints are organized into routes, controllers, and services for a clean and scalable architecture.

-   `/src/routes`: Defines the API endpoints (e.g., `/api/symptom-checker`).
-   `/src/controllers`: Handles the incoming request and outgoing response logic for each route.
-   `/src/services`: Contains the core business logic, interacting with the database and external APIs like Gemini.
-   `/src/middleware`: Contains middleware functions, such as for authentication.
-   `/prisma`: Contains the database schema, migrations, and seed script.
