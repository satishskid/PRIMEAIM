
const { PrismaClient } = require('@prisma/client');
// FIX: Corrected import path for types.
import { BusinessType, MarketplaceApplicationStatus, UserStatus } from '../../packages/types/index';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const indianCities = [
    'Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Ahmedabad', 'Chennai', 'Kolkata', 'Surat', 'Pune', 'Jaipur'
];

const indianNames = [
    'Aarav', 'Vihaan', 'Advik', 'Vivaan', 'Ananya', 'Diya', 'Ishaan', 'Aanya', 'Reyansh', 'Myra',
    'Kabir', 'Aarohi', 'Rohan', 'Kiara', 'Arjun', 'Siya', 'Aryan', 'Navya', 'Shaurya', 'Pari'
];

const providersData = [
    // Approved Pharmacies (5)
    { name: 'Apollo Pharmacy', type: BusinessType.PHARMACY, status: MarketplaceApplicationStatus.APPROVED, tier: 'STANDARD', promo: '15% off on health supplements.' },
    { name: 'MedPlus', type: BusinessType.PHARMACY, status: MarketplaceApplicationStatus.APPROVED, tier: 'BUDGET', promo: 'Lowest prices guaranteed.' },
    { name: 'Wellness Forever', type: BusinessType.PHARMACY, status: MarketplaceApplicationStatus.APPROVED, tier: 'PREMIUM', promo: '24/7 service and free express delivery.' },
    { name: 'NetMeds', type: BusinessType.PHARMACY, status: MarketplaceApplicationStatus.APPROVED, tier: 'STANDARD', promo: '' },
    { name: '1mg Pharmacy', type: BusinessType.PHARMACY, status: MarketplaceApplicationStatus.APPROVED, tier: 'BUDGET', promo: 'Flat 20% off on first order.' },
    // Approved Labs (5)
    { name: 'Dr. Lal PathLabs', type: BusinessType.LAB, status: MarketplaceApplicationStatus.APPROVED, tier: 'PREMIUM', promo: 'Most trusted reports in India.' },
    { name: 'Metropolis Healthcare', type: BusinessType.LAB, status: MarketplaceApplicationStatus.APPROVED, tier: 'STANDARD', promo: 'Home collection available.' },
    { name: 'Thyrocare', type: BusinessType.LAB, status: MarketplaceApplicationStatus.APPROVED, tier: 'BUDGET', promo: 'Affordable wellness packages.' },
    { name: 'SRL Diagnostics', type: BusinessType.LAB, status: MarketplaceApplicationStatus.APPROVED, tier: 'STANDARD', promo: '' },
    { name: 'Pathkind Labs', type: BusinessType.LAB, status: MarketplaceApplicationStatus.APPROVED, tier: 'STANDARD', promo: 'Fast and accurate results.' },
    // Approved Clinics (5)
    { name: 'Manipal Hospitals', type: BusinessType.CLINIC, status: MarketplaceApplicationStatus.APPROVED, tier: 'PREMIUM', promo: 'World-class multi-specialty care.' },
    { name: 'Fortis Healthcare', type: BusinessType.CLINIC, status: MarketplaceApplicationStatus.APPROVED, tier: 'PREMIUM', promo: '' },
    { name: 'Max Healthcare', type: BusinessType.CLINIC, status: MarketplaceApplicationStatus.APPROVED, tier: 'STANDARD', promo: 'Comprehensive family health check-ups.' },
    { name: 'Narayana Health', type: BusinessType.CLINIC, status: MarketplaceApplicationStatus.APPROVED, tier: 'BUDGET', promo: 'Quality healthcare for all.' },
    { name: 'Aster DM Healthcare', type: BusinessType.CLINIC, status: MarketplaceApplicationStatus.APPROVED, tier: 'STANDARD', promo: '' },
    // Pending Applications (3)
    { name: 'Jiva Ayurveda Clinic', type: BusinessType.CLINIC, status: MarketplaceApplicationStatus.SUBMITTED, tier: 'STANDARD', promo: 'Holistic wellness through Ayurveda.' },
    { name: 'Healthians Lab', type: BusinessType.LAB, status: MarketplaceApplicationStatus.SUBMITTED, tier: 'BUDGET', promo: 'Preventive health tests at home.' },
    { name: 'Generic Aadhaar Pharmacy', type: BusinessType.PHARMACY, status: MarketplaceApplicationStatus.SUBMITTED, tier: 'BUDGET', promo: '' },
];

async function main() {
    console.log('Start seeding...');

    // 1. Create a mock Admin User
    console.log('Seeding admin user...');
    const adminPassword = await bcrypt.hash('admin123', 10);
    const admin = await prisma.user.upsert({
        where: { email: 'admin@pca.com' },
        update: {},
        create: {
            email: 'admin@pca.com',
            password: adminPassword,
            businessName: 'PCA Admin',
            businessType: BusinessType.CLINIC, // Placeholder
            isAdmin: true,
            isActive: true,
            status: UserStatus.ACTIVE,
        },
    });
    console.log(`Created admin user: ${admin.email}`);

    // 2. Patient Profiles (Conceptual)
    console.log('Seeding patient profiles (conceptual)...');
    for (let i = 0; i < 10; i++) {
        console.log(`Conceptual patient created: ${indianNames[i + 10]} (Age: ${25 + i})`);
    }

    // 3. Create Marketplace Applications and associated Users/Providers
    console.log('Seeding providers and applications...');
    for (const provider of providersData) {
        const city = indianCities[Math.floor(Math.random() * indianCities.length)];
        const businessName = `${provider.name} - ${city}`;
        const contactEmail = `${provider.name.toLowerCase().replace(/\s/g, '')}.${city.toLowerCase()}@example.com`;

        const application = await prisma.marketplaceApplication.upsert({
            where: { contactEmail: contactEmail },
            update: {},
            create: {
                businessName: businessName,
                businessType: provider.type,
                address: `123, ${city} Main Road, ${city}, India`,
                contactEmail: contactEmail,
                contactPhone: '555-123-4567',
                regulatoryComplianceNotes: 'All necessary local and national licenses are current and valid.',
                attestedCompliance: true,
                status: provider.status,
                pricingTier: provider.tier,
                promotionalMessage: provider.promo,
                rateListNotes: 'Standard rates apply. Please contact for bulk pricing or special packages.',
            },
        });
        console.log(`Created application for: ${application.businessName} with status ${application.status}`);

        if (provider.status === MarketplaceApplicationStatus.APPROVED) {
            const userPassword = await bcrypt.hash('password123', 10);
            const user = await prisma.user.upsert({
                where: { email: contactEmail },
                update: {
                    pricingTier: provider.tier,
                    promotionalMessage: provider.promo,
                },
                create: {
                    email: contactEmail,
                    password: userPassword,
                    businessName: businessName,
                    businessType: provider.type,
                    isActive: true,
                    status: UserStatus.ACTIVE,
                    pricingTier: provider.tier,
                    promotionalMessage: provider.promo,
                    application: {
                        connect: { id: application.id }
                    }
                }
            });
            console.log(`Created user for approved provider: ${user.email}`);
            
            if(provider.type === BusinessType.CLINIC) {
                await prisma.clinicProviderProfile.upsert({ where: { userId: user.id }, update: {}, create: { applicationId: application.id, userId: user.id }});
            } else if (provider.type === BusinessType.LAB) {
                 await prisma.labProviderProfile.upsert({ where: { userId: user.id }, update: {}, create: { applicationId: application.id, userId: user.id }});
            } else if (provider.type === BusinessType.PHARMACY) {
                 await prisma.pharmacyProviderProfile.upsert({ where: { userId: user.id }, update: {}, create: { applicationId: application.id, userId: user.id }});
            }
             console.log(`Created ${provider.type} profile for ${user.businessName}`);
        }
    }

    // 4. Seed initial Algorithm Configuration
    console.log('Seeding algorithm configuration...');
    await prisma.algorithmConfig.upsert({
        where: { id: 'singleton' },
        update: {},
        create: {
            id: 'singleton',
            pharmacyPriceWeight: 0.5,
            pharmacySpeedWeight: 0.25,
            pharmacyQualityWeight: 0.25,
            pharmacyPatientPreferenceImpact: 0.1,
            labPriceWeight: 0.4,
            labSpeedWeight: 0.3,
            labQualityWeight: 0.3,
            labPatientPreferenceImpact: 0.1,
        }
    });
    console.log('Default algorithm weights set.');

    console.log('Seeding finished.');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });