// Symptom Checker & Chat
export interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
}

export interface GeneratedQuestion {
  question: string;
  metaSymptomQuestions: {
    prompt: string;
    options: string[];
  }[];
  isFinal: boolean;
}

export interface ProvisionalDiagnosis {
  condition: string;
  explanation: string;
}

// Patient & Episode
export interface PatientProfile {
  name?: string;
  age?: string;
  pastHistory?: string;
  habits?: string;
}

export interface Episode {
  id: string;
  date: string;
  patientName?: string;
  initialSymptomsSummary: string;
  provisionalDiagnosisSummary: string;
  clinicName?: string;
  prescriptionSummary?: string;
}

// Doctor Assist & Prescription
export enum PrescriptionTab {
  FORMAL = 'Formal Prescription',
  EDUCATION = 'Patient Education',
}

export interface Medication {
    name: string;
    dosage: string;
    instructions: string;
    education: string;
    adherenceTips: string;
}

export interface LabTest {
    name: string;
    reason: string;
    education: string;
}

export interface Prescription {
  medications: Medication[];
  tests: LabTest[];
  generalAdvice: string;
}

export interface DoctorNoteSuggestion {
  type: string;
  suggestion: string;
}

export interface DDxItem {
  condition: string;
  rationale: string;
}

export interface DDxActionSuggestion {
  suggestedMedications: {
    name: string;
    typicalDosage: string;
    typicalInstructions: string;
  }[];
  suggestedTests: {
    name: string;
    reason: string;
  }[];
}

// Clinic & Booking
export interface LocationDetails {
    addressLine1: string;
    city: string;
}

export interface SystemCalculatedRating {
    score: number;
    rationale: string;
    lastCalculated?: string;
}

export interface Clinic {
  id: string;
  name: string;
  mainSpecialties: string[];
  locationDetails: LocationDetails;
  systemCalculatedRating: SystemCalculatedRating;
  doctorName: string;
  operationalHours: string;
  bookingSystemFeatures: string[];
  clinicLicense: string;
}

export interface Appointment {
  patientProfile?: PatientProfile;
  patientSymptoms: string;
  provisionalDiagnosis?: ProvisionalDiagnosis;
  clinic: Clinic;
  dateTime: string;
  prescription?: Prescription;
}

// Marketplace & Providers
export enum BusinessType {
  CLINIC = 'CLINIC',
  PHARMACY = 'PHARMACY',
  LAB = 'LAB',
}

export interface PharmacyProvider {
  id: string;
  name: string;
  // ... other fields
}

export interface PharmacyOrderBroadcastResult {
    message: string;
    orderId: string;
}

export interface ProviderProfile {
    id: string;
    userId: string;
    name: string;
    businessType: BusinessType;
    // ... many more fields
}

export interface PatientFeedbackSummary {
    averageRating: number;
    reviewCount: number;
}


// Admin & Onboarding
export enum MarketplaceApplicationStatus {
    SUBMITTED = 'SUBMITTED',
    IN_REVIEW = 'IN_REVIEW',
    APPROVED = 'APPROVED',
    REJECTED = 'REJECTED'
}

export enum UserStatus {
    ACTIVE = 'ACTIVE',
    SUSPENDED = 'SUSPENDED',
    DEACTIVATED = 'DEACTIVATED'
}

export interface MarketplaceApplication {
  id: string;
  businessName: string;
  businessType: BusinessType;
  address: string;
  contactEmail: string;
  contactPhone: string;
  website?: string;
  regulatoryComplianceNotes?: string;
  attestedCompliance: boolean;
  status: MarketplaceApplicationStatus;
  
  // Pricing & Commercials
  pricingTier?: string;
  rateListNotes?: string;
  promotionalMessage?: string;
  
  // Operational Details
  operationalHoursNotes?: string;
  communicationChannelNotes?: string;
  keyAccreditationsNotes?: string;
  
  // Clinic Specific
  clinicSpecialties?: string[];
  doctorCount?: number;
  bookingSystemNotes?: string;
  specialEquipmentNotes?: string;
  
  // Lab Specific
  labTestTypes?: string[];
  labCertificationsNotes?: string;
  homeSampleCollectionNotes?: string;
  
  // Pharmacy Specific
  pharmacyServices?: string[];
  prescriptionDelivery?: boolean;
  deliveryOptionsNotes?: string;
}

export interface AdminDashboardData {
    applicationCounts: Record<MarketplaceApplicationStatus, number>;
    providerCounts: Record<BusinessType, number>;
    recentApplications: MarketplaceApplication[];
    activeUsers: any[]; // Define a proper User type later if needed
}

export interface AlgorithmFactorWeights {
  priceWeight: number;
  speedWeight: number;
  qualityWeight: number;
  patientPreferenceImpact: number;
}

export interface UpdateAlgorithmFactorsRequest {
    type: 'PHARMACY' | 'LAB';
    factors: Partial<AlgorithmFactorWeights>;
}

export interface UpdateAlgorithmFactorsResponse {
    success: boolean;
    updatedFactors: any;
}

export interface ErrorResponse {
    error: string;
    message?: string;
}


// General
export interface Task {
  id: string;
  text: string;
  completed: boolean;
  dueDate?: string;
  notificationSent: boolean;
}
