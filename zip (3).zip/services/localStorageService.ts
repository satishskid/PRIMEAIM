
// FIX: Corrected import path for types
import { PatientProfile, Episode, Task } from '../../packages/types/index';

const PROFILE_KEY = 'primaryCareAssistantProfile';
const EPISODES_KEY = 'primaryCareAssistantEpisodes';
const TASKS_KEY = 'primaryCareAssistantTasks';


export const savePatientProfile = (profile: PatientProfile): void => {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch (error) {
    console.error("Could not save patient profile:", error);
  }
};

export const loadPatientProfile = (): PatientProfile | null => {
  try {
    const profileJson = localStorage.getItem(PROFILE_KEY);
    return profileJson ? JSON.parse(profileJson) : null;
  } catch (error) {
    console.error("Could not load patient profile:", error);
    return null;
  }
};

export const saveEpisode = (episode: Episode | null, clearAll: boolean = false): void => {
  if (clearAll) {
      localStorage.removeItem(EPISODES_KEY);
      return;
  }
  if (!episode) return;
  
  try {
      const existingEpisodes = loadEpisodes();
      const newEpisodes = [episode, ...existingEpisodes];
      localStorage.setItem(EPISODES_KEY, JSON.stringify(newEpisodes));
  } catch (error) {
      console.error("Could not save episode:", error);
  }
};


export const loadEpisodes = (): Episode[] => {
    try {
        const episodesJson = localStorage.getItem(EPISODES_KEY);
        if (!episodesJson) return [];
        const episodes = JSON.parse(episodesJson);
        return Array.isArray(episodes) ? episodes : [];
    } catch (error) {
        console.error("Could not load episodes:", error);
        return [];
    }
};

export const saveTasks = (tasks: Task[]): void => {
    try {
        localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
    } catch (error) {
        console.error("Could not save tasks:", error);
    }
};

export const loadTasks = (): Task[] => {
    try {
        const tasksJson = localStorage.getItem(TASKS_KEY);
        if (!tasksJson) return [];
        const tasks = JSON.parse(tasksJson);
        return Array.isArray(tasks) ? tasks : [];
    } catch (error) {
        console.error("Could not load tasks:", error);
        return [];
    }
};