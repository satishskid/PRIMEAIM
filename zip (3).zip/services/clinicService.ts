
// FIX: Corrected import path for types.
import { Clinic, BusinessType } from '../../packages/types/index';
import { apiClient } from './apiClient';

/**
 * Fetches recommended clinics from the backend.
 * In a real app, this would be a more sophisticated API call.
 * @param diagnosis The provisional diagnosis to help filter clinics.
 */
export const fetchClinics = async (diagnosis: string | null): Promise<Clinic[]> => {
    // The backend endpoint will handle the logic of finding suitable clinics.
    // We can pass the diagnosis as a query parameter.
    const clinics = await apiClient.get<Clinic[]>(`/api/marketplace/providers/clinics?diagnosis=${encodeURIComponent(diagnosis || '')}`);
    
    // Simulate some basic frontend filtering or sorting if needed, but backend should do heavy lifting.
    return clinics.sort((a, b) => (b.systemCalculatedRating?.score || 0) - (a.systemCalculatedRating?.score || 0));
};