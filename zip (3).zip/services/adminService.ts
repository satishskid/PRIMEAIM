
import { 
    MarketplaceApplication, 
    AdminDashboardData,
    UserStatus,
    AlgorithmFactorWeights,
    BusinessType
// FIX: Corrected import path for types.
} from '../../packages/types/index';
import { apiClient } from './apiClient';

export const getAdminDashboardData = (): Promise<AdminDashboardData> => {
    return apiClient.get('/api/admin/dashboard');
};

export const updateApplicationStatus = (id: string, status: 'APPROVED' | 'REJECTED'): Promise<any> => {
    return apiClient.put(`/api/admin/applications/${id}`, { status });
};

export const updateUserStatus = (id: string, status: UserStatus): Promise<any> => {
    return apiClient.put(`/api/admin/users/${id}/status`, { status });
};

export const getAlgorithmFactors = (): Promise<any> => {
    return apiClient.get('/api/admin/config/algorithm-factors');
};

export const updateAlgorithmFactors = (type: 'PHARMACY' | 'LAB', factors: Partial<AlgorithmFactorWeights>): Promise<any> => {
    return apiClient.put('/api/admin/config/algorithm-factors', { type, factors });
};

export const registerProvider = (applicationData: MarketplaceApplication): Promise<{ application: MarketplaceApplication }> => {
    return apiClient.post('/api/marketplace/register', applicationData);
};