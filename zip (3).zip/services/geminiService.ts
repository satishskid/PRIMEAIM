
import { apiClient } from './apiClient';
import { 
    GeneratedQuestion, 
    ProvisionalDiagnosis, 
    PatientProfile,
    ChatMessage,
    Prescription,
    DoctorNoteSuggestion,
    DDxItem,
    DDxActionSuggestion,
    PharmacyProvider,
    PharmacyOrderBroadcastResult
// FIX: Corrected import path for types.
} from '../../packages/types/index';

export const getInitialAssessmentAndQuestion = (
    symptoms: string, 
    history: ChatMessage[], 
    profile?: PatientProfile
): Promise<GeneratedQuestion> => {
    return apiClient.post('/api/symptom-checker/initial-assessment', { symptoms, history, profile });
};

export const getProvisionalDiagnosis = (
    history: ChatMessage[], 
    profile?: PatientProfile
): Promise<ProvisionalDiagnosis> => {
    return apiClient.post('/api/symptom-checker/provisional-diagnosis', { history, profile });
};

export const generateDoctorNotes = (
    symptoms: string, 
    provisionalDiagnosis: string, 
    profile?: PatientProfile
): Promise<string> => {
    return apiClient.post('/api/symptom-checker/doctor-notes', { symptoms, provisionalDiagnosis, profile }, { responseAs: 'text' });
};

export const generatePrescriptionWithEducation = (
    condition: string,
    summary: string,
    doctorName: string,
    clinicAddress: string,
    clinicLicense: string,
): Promise<Prescription> => {
    return apiClient.post('/api/prescription/generate-full', {
        condition,
        summary,
        doctorName,
        clinicAddress,
        clinicLicense,
    });
};

export const generateDoctorNoteSuggestions = (
    currentNotes: string,
    provisionalDiagnosis: string,
    profile?: PatientProfile
): Promise<DoctorNoteSuggestion[]> => {
    return apiClient.post('/api/doctor-assist/note-suggestions', { currentNotes, provisionalDiagnosis, profile });
};

export const generatePrescriptionKeywords = (
    provisionalDiagnosis: string,
    currentSummary: string
): Promise<string[]> => {
    return apiClient.post('/api/prescription/keywords', { provisionalDiagnosis, currentSummary });
};

export const generateDifferentialDiagnoses = (
    symptoms: string,
    provisionalDiagnosis: string,
    notes: string,
    profile?: PatientProfile
): Promise<DDxItem[]> => {
    return apiClient.post('/api/doctor-assist/ddx', { symptoms, provisionalDiagnosis, notes, profile });
};

export const suggestActionsForDDx = (
    condition: string,
    profile?: PatientProfile
): Promise<DDxActionSuggestion> => {
    return apiClient.post('/api/doctor-assist/ddx-actions', { condition, profile });
};

export const listPharmacies = (): Promise<PharmacyProvider[]> => {
    return apiClient.get('/api/marketplace/providers/pharmacies');
};

export const broadcastPharmacyOrder = (
    patient: PatientProfile,
    prescription: Prescription
): Promise<PharmacyOrderBroadcastResult> => {
    return apiClient.post('/api/orders/broadcast/pharmacy', { patient, prescription });
};