import { apiClient } from './apiClient';

// In a real app, you would define stricter types for auth responses
interface AuthResponse {
    token: string;
    user: {
        id: string;
        email: string;
        businessName: string;
        isAdmin?: boolean;
    };
}

/**
 * Logs in a user.
 * @param credentials - The user's email and password.
 */
export const login = async (credentials: { email: string, password: string }): Promise<AuthResponse> => {
    const response = await apiClient.post<AuthResponse>('/api/auth/login', credentials);
    // In a real app, you'd store the token securely (e.g., in an HttpOnly cookie managed by the server, or localStorage for simple cases)
    if (response.token) {
        localStorage.setItem('authToken', response.token);
    }
    return response;
};

/**
 * Registers a new user or provider.
 * @param userData - The data for the new user account.
 */
export const register = async (userData: any): Promise<AuthResponse> => {
    const response = await apiClient.post<AuthResponse>('/api/auth/register', userData);
    if (response.token) {
        localStorage.setItem('authToken', response.token);
    }
    return response;
};

/**
 * Logs out the current user.
 */
export const logout = (): void => {
    // Clear the token from storage
    localStorage.removeItem('authToken');
    // You might also want to call a backend endpoint to invalidate the token server-side
    console.log('User logged out.');
};
