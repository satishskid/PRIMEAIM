import React, { useState } from 'react';
import { useAppStore, AppStage } from './store/appStore';
import WelcomeStage from './components/WelcomeStage';
import PatientProfileStage from './components/PatientProfileStage';
import SymptomInputStage from './components/SymptomInputStage';
import ClinicSelectionStage from './components/ClinicSelectionStage';
import BookingStage from './components/BookingStage';
import DoctorPatientViewStage from './components/DoctorPatientViewStage';
import PharmacyOrderView from './components/PharmacyOrderView';
import InteractionHistoryView from './components/InteractionHistoryView';
import MarketplaceWelcomeStage from './components/MarketplaceWelcomeStage';
import MarketplaceOnboardingFormStage from './components/MarketplaceOnboardingFormStage';
import MarketplaceConfirmationStage from './components/MarketplaceConfirmationStage';
import AdminLoginStage from './components/AdminLoginStage';
import AdminDashboardStage from './components/AdminDashboardStage';
import { Icons } from './constants';
import SettingsModal from './components/SettingsModal';
import ApiKeyStage from './components/ApiKeyStage';

const App: React.FC = () => {
    const { currentStage, isAdmin } = useAppStore(state => ({
        currentStage: state.currentStage,
        isAdmin: state.isAdmin,
    }));
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);

    const renderStage = () => {
        switch (currentStage) {
            case AppStage.API_KEY_CHECK:
                return <ApiKeyStage />;
            case AppStage.WELCOME:
                return <WelcomeStage />;
            case AppStage.PATIENT_PROFILE:
                return <PatientProfileStage />;
            case AppStage.SYMPTOM_INPUT:
                return <SymptomInputStage />;
            case AppStage.CLINIC_SELECTION:
                return <ClinicSelectionStage />;
            case AppStage.BOOKING:
                return <BookingStage />;
            case AppStage.DOCTOR_PATIENT_VIEW:
                return <DoctorPatientViewStage />;
            case AppStage.PHARMACY_ORDER:
                return <PharmacyOrderView />;
            case AppStage.INTERACTION_HISTORY:
                return <InteractionHistoryView />;
            case AppStage.MARKETPLACE_WELCOME:
                return <MarketplaceWelcomeStage />;
            case AppStage.MARKETPLACE_ONBOARDING:
                return <MarketplaceOnboardingFormStage />;
            case AppStage.MARKETPLACE_CONFIRMATION:
                return <MarketplaceConfirmationStage />;
            case AppStage.ADMIN_LOGIN:
                return <AdminLoginStage />;
            case AppStage.ADMIN_DASHBOARD:
                return isAdmin ? <AdminDashboardStage /> : <AdminLoginStage />;
            default:
                return <WelcomeStage />;
        }
    };

    return (
        <div className="bg-slate-100 min-h-screen font-sans text-slate-800">
            <header className="bg-white shadow-sm sticky top-0 z-10">
                <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <Icons.Sparkles className="w-8 h-8 text-blue-600" />
                        <h1 className="text-xl font-bold text-slate-800">Primary Care Assistant</h1>
                    </div>
                    <button 
                        onClick={() => setIsSettingsOpen(true)}
                        className="p-2 rounded-full hover:bg-slate-100 transition-colors"
                        aria-label="Settings"
                    >
                        <Icons.Cog className="w-6 h-6 text-slate-600" />
                    </button>
                </nav>
            </header>
            <main className="container mx-auto p-4 md:p-8">
                {renderStage()}
            </main>
            <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
        </div>
    );
};

export default App;