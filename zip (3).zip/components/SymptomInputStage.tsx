
import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import * as geminiService from '../services/geminiService';
// FIX: Corrected import path for types.
import { ChatMessage, GeneratedQuestion } from '../../packages/types/index';
import LoadingSpinner from './LoadingSpinner';
import { Icons } from '../constants';

const SymptomInputStage: React.FC = () => {
    const { 
        setProvisionalDiagnosis, 
        goToClinicSelection, 
        patientProfile,
        addMessage,
        chatHistory,
        setChatHistory
    } = useAppStore();
    const [currentSymptoms, setCurrentSymptoms] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [aiQuestion, setAiQuestion] = useState<GeneratedQuestion | null>(null);

    const handleInitialSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentSymptoms.trim()) {
            setError('Please describe your symptoms.');
            return;
        }
        setError(null);
        setIsLoading(true);

        const userMessage: ChatMessage = { sender: 'user', text: currentSymptoms };
        const newHistory = [...chatHistory, userMessage];
        addMessage(userMessage);

        try {
            const result = await geminiService.getInitialAssessmentAndQuestion(currentSymptoms, [], patientProfile || undefined);
            if (result) {
                setAiQuestion(result);
                const aiMessage: ChatMessage = { sender: 'ai', text: result.question };
                addMessage(aiMessage);
            } else {
                setError('Could not get a response from the AI. Please try again.');
            }
        } catch (err) {
            setError('An error occurred. Please try again.');
        } finally {
            setIsLoading(false);
            setCurrentSymptoms(''); // Clear input for next response
        }
    };
    
    const handleConversationSubmit = async (text: string) => {
        setError(null);
        setIsLoading(true);

        const userMessage: ChatMessage = { sender: 'user', text };
        addMessage(userMessage);
        
        try {
            // Send the whole history for context
            const result = await geminiService.getInitialAssessmentAndQuestion(text, chatHistory, patientProfile || undefined);
            if (result) {
                if (result.isFinal) {
                    await handleFinalize();
                } else {
                    setAiQuestion(result);
                    const aiMessage: ChatMessage = { sender: 'ai', text: result.question };
                    addMessage(aiMessage);
                }
            } else {
                setError('Could not get a response from the AI. Please try again.');
            }
        } catch (err) {
            setError('An error occurred. Please try again.');
        } finally {
            setIsLoading(false);
        }
    }
    
    const handleFinalize = async () => {
        setIsLoading(true);
        try {
            const diagnosis = await geminiService.getProvisionalDiagnosis(chatHistory, patientProfile || undefined);
            if (diagnosis) {
                setProvisionalDiagnosis(diagnosis);
                goToClinicSelection();
            } else {
                setError("Could not finalize the assessment. Please try again.");
            }
        } catch (err) {
            setError("An error occurred while finalizing. Please try again.");
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold text-slate-800 text-center mb-2">Symptom Checker</h2>
            <p className="text-center text-slate-500 mb-6">
                {chatHistory.length === 0 
                    ? "Please describe your symptoms in detail. The more information you provide, the better the initial assessment."
                    : "Please answer the questions to help us understand your condition better."
                }
            </p>

            {/* Chat history */}
            <div className="mb-4 space-y-4 max-h-96 overflow-y-auto custom-scrollbar p-4 bg-slate-50 rounded-lg border">
                {chatHistory.map((msg, index) => (
                    <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-md p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-slate-200 text-slate-800 rounded-bl-none'}`}>
                           <p>{msg.text}</p>
                        </div>
                    </div>
                ))}
                {isLoading && <div className="flex justify-start"><LoadingSpinner size="sm" text="Thinking..."/></div>}
            </div>

            {error && <p className="text-red-500 text-sm text-center mb-4">{error}</p>}
            
            {/* Input form */}
            {chatHistory.length === 0 ? (
                 <form onSubmit={handleInitialSubmit} className="space-y-4">
                    <textarea
                        value={currentSymptoms}
                        onChange={(e) => setCurrentSymptoms(e.target.value)}
                        rows={4}
                        className="w-full p-3 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 custom-scrollbar"
                        placeholder="e.g., I have a sharp headache on the right side of my head, and I'm sensitive to light."
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:bg-slate-400"
                    >
                        {isLoading ? <LoadingSpinner size="sm"/> : <Icons.Send className="w-5 h-5"/>}
                        Start Assessment
                    </button>
                </form>
            ) : (
                <div className="space-y-3">
                    {aiQuestion?.metaSymptomQuestions?.map((metaQ, index) => (
                         <div key={index}>
                            <p className="font-semibold text-slate-700 mb-2">{metaQ.prompt}</p>
                            <div className="flex flex-wrap gap-2">
                                {metaQ.options.map((opt, i) => (
                                    <button key={i} onClick={() => handleConversationSubmit(`${metaQ.prompt}: ${opt}`)} disabled={isLoading} className="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-full hover:bg-blue-200 disabled:bg-slate-200 disabled:text-slate-500">
                                        {opt}
                                    </button>
                                ))}
                            </div>
                        </div>
                    ))}
                    <button onClick={handleFinalize} disabled={isLoading} className="w-full mt-4 text-sm text-center text-slate-600 hover:text-blue-700">
                        I think that's enough information, proceed to next step.
                    </button>
                </div>
            )}
        </div>
    );
};

export default SymptomInputStage;