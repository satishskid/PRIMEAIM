import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import * as geminiService from '../services/geminiService';
// FIX: Corrected import path for types
import { Prescription, PrescriptionTab, DoctorNoteSuggestion, DDxItem, DDxActionSuggestion } from '../../packages/types/index';
import LoadingSpinner from './LoadingSpinner';
import { Icons } from '../constants';
import Modal from './Modal';
import FeedbackModal from './FeedbackModal'; // Import the new component

const DoctorPatientViewStage: React.FC = () => {
    const { appointment, setPrescription, goToPharmacyOrder, resetEpisode } = useAppStore();
    const [doctorNotes, setDoctorNotes] = useState('');
    const [prescriptionSummary, setPrescriptionSummary] = useState('');
    const [activeTab, setActiveTab] = useState<PrescriptionTab>(PrescriptionTab.FORMAL);
    const [generatedPrescription, setGeneratedPrescription] = useState<Prescription | null>(null);
    const [isLoading, setIsLoading] = useState({ notes: false, prescription: false, keywords: false, ddx: false, ddxAction: false });

    const [noteSuggestions, setNoteSuggestions] = useState<DoctorNoteSuggestion[]>([]);
    const [keywordSuggestions, setKeywordSuggestions] = useState<string[]>([]);
    const [ddxItems, setDdxItems] = useState<DDxItem[]>([]);
    const [selectedDdx, setSelectedDdx] = useState<DDxItem | null>(null);
    const [ddxActions, setDdxActions] = useState<DDxActionSuggestion | null>(null);
    const [isDdxModalOpen, setIsDdxModalOpen] = useState(false);
    const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);


    useEffect(() => {
        if (appointment) {
            setIsLoading(prev => ({ ...prev, notes: true }));
            geminiService.generateDoctorNotes(
                appointment.patientSymptoms,
                appointment.provisionalDiagnosis?.condition || 'N/A',
                appointment.patientProfile
            ).then(notes => {
                setDoctorNotes(notes);
            }).finally(() => setIsLoading(prev => ({ ...prev, notes: false })));
        }
    }, [appointment]);

    if (!appointment) {
        return <div className="text-center p-8">No appointment data found.</div>;
    }

    const handleGeneratePrescription = async () => {
        setIsLoading(prev => ({ ...prev, prescription: true }));
        const fullSummary = `Clinical Notes: ${doctorNotes}\n\nPrescription Intent: ${prescriptionSummary}`;
        const result = await geminiService.generatePrescriptionWithEducation(
            appointment.provisionalDiagnosis?.condition || 'General Checkup',
            fullSummary,
            appointment.clinic.doctorName,
            `${appointment.clinic.locationDetails.addressLine1}, ${appointment.clinic.locationDetails.city}`,
            appointment.clinic.clinicLicense,
        );
        setGeneratedPrescription(result);
        setIsLoading(prev => ({ ...prev, prescription: false }));
    };
    
    const handleNoteSuggestion = async () => {
        if (!appointment) return;
        const suggestions = await geminiService.generateDoctorNoteSuggestions(doctorNotes, appointment.provisionalDiagnosis?.condition || 'N/A', appointment.patientProfile);
        setNoteSuggestions(suggestions);
    }

    const handleKeywordSuggestion = async () => {
        if (!appointment) return;
        setIsLoading(prev => ({ ...prev, keywords: true }));
        const keywords = await geminiService.generatePrescriptionKeywords(appointment.provisionalDiagnosis?.condition || 'N/A', prescriptionSummary);
        setKeywordSuggestions(keywords);
        setIsLoading(prev => ({ ...prev, keywords: false }));
    }

    const handleGenerateDdx = async () => {
        if (!appointment) return;
        setIsDdxModalOpen(true);
        setIsLoading(prev => ({ ...prev, ddx: true }));
        const ddx = await geminiService.generateDifferentialDiagnoses(appointment.patientSymptoms, appointment.provisionalDiagnosis?.condition || 'N/A', doctorNotes, appointment.patientProfile);
        setDdxItems(ddx || []);
        setIsLoading(prev => ({ ...prev, ddx: false }));
    };

    const handleSelectDdx = async (ddx: DDxItem) => {
        if (!appointment) return;
        setSelectedDdx(ddx);
        setIsLoading(prev => ({ ...prev, ddxAction: true }));
        const actions = await geminiService.suggestActionsForDDx(ddx.condition, appointment.patientProfile);
        setDdxActions(actions);
        setIsLoading(prev => ({ ...prev, ddxAction: false }));
    };
    
    const handleFinishAndOrder = () => {
        if (generatedPrescription) {
            setPrescription(generatedPrescription);
            goToPharmacyOrder();
        }
    };

    const handleFeedbackSubmit = (rating: number, feedback: string) => {
        console.log("Feedback Received:", { rating, feedback }); // In a real app, send this to a backend service.
        setIsFeedbackModalOpen(false);
        resetEpisode(); // Now reset the episode after feedback is submitted
    };
    
    const { patientProfile, clinic, dateTime, patientSymptoms, provisionalDiagnosis } = appointment;

    return (
        <div className="max-w-6xl mx-auto p-4 grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Patient & Visit Info */}
            <div className="lg:col-span-1 space-y-4">
                <div className="bg-white p-4 rounded-lg shadow">
                    <h3 className="font-bold text-lg text-slate-800 mb-2">Patient Details</h3>
                    <p><strong>Name:</strong> {patientProfile?.name}</p>
                    <p><strong>Age:</strong> {patientProfile?.age}</p>
                    <p><strong>History:</strong> {patientProfile?.pastHistory}</p>
                    <p><strong>Habits:</strong> {patientProfile?.habits}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                    <h3 className="font-bold text-lg text-slate-800 mb-2">Visit Details</h3>
                    <p><strong>Clinic:</strong> {clinic.name}</p>
                    <p><strong>Date:</strong> {new Date(dateTime).toLocaleString()}</p>
                    <p><strong>Chief Complaint:</strong> {patientSymptoms}</p>
                    <p><strong>Provisional Diagnosis:</strong> {provisionalDiagnosis?.condition}</p>
                </div>
                 <div className="bg-white p-4 rounded-lg shadow">
                    <h3 className="font-bold text-lg text-slate-800 mb-2">Doctor's AI Assistant</h3>
                    <button onClick={handleGenerateDdx} className="w-full text-left p-3 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-2">
                        <Icons.Search className="w-5 h-5"/>
                        <span>Differential Diagnosis (DDx)</span>
                    </button>
                </div>
            </div>

            {/* Right Column: Doctor's Workspace */}
            <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow space-y-6">
                <div>
                    <h3 className="font-bold text-lg text-slate-800 mb-2">Clinical Notes</h3>
                    <textarea
                        value={doctorNotes}
                        onChange={(e) => setDoctorNotes(e.target.value)}
                        rows={8}
                        className="w-full p-2 border rounded-md bg-slate-50 custom-scrollbar"
                        placeholder="Loading AI-generated notes..."
                    />
                    <div className="flex items-center gap-2 mt-2">
                         <button onClick={handleNoteSuggestion} className="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-full hover:bg-blue-200">
                           Suggest
                         </button>
                         {noteSuggestions.map((s, i) => (
                           <button key={i} onClick={() => setDoctorNotes(prev => `${prev} ${s.suggestion}`)} className="px-3 py-1 text-sm bg-slate-100 text-slate-700 rounded-full hover:bg-slate-200" title={s.type}>
                               {s.suggestion}
                           </button>
                         ))}
                    </div>
                </div>

                <div>
                    <h3 className="font-bold text-lg text-slate-800 mb-2">Prescription & Plan</h3>
                    <textarea
                        value={prescriptionSummary}
                        onChange={(e) => setPrescriptionSummary(e.target.value)}
                        rows={5}
                        className="w-full p-2 border rounded-md"
                        placeholder="Enter prescription details, e.g., 'Amoxicillin 500mg TID for 7 days. Advise rest and hydration.'"
                    />
                    <div className="flex items-center gap-2 mt-2">
                        <button onClick={handleKeywordSuggestion} className="px-3 py-1 text-sm bg-blue-100 text-blue-800 rounded-full hover:bg-blue-200 flex items-center gap-1">
                           {isLoading.keywords ? <LoadingSpinner size="sm" /> : <Icons.Sparkles className="w-4 h-4"/>} Keywords
                         </button>
                         {keywordSuggestions.map((kw, i) => (
                           <button key={i} onClick={() => setPrescriptionSummary(prev => `${prev} ${kw}.`)} className="px-3 py-1 text-sm bg-slate-100 text-slate-700 rounded-full hover:bg-slate-200">
                               {kw}
                           </button>
                         ))}
                    </div>
                     <button onClick={handleGeneratePrescription} disabled={isLoading.prescription || !prescriptionSummary} className="mt-4 w-full bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-slate-400 flex items-center justify-center gap-2">
                        {isLoading.prescription ? <LoadingSpinner size="sm" /> : <Icons.ChatBubble className="w-5 h-5"/>}
                        Generate Patient-Friendly Prescription
                    </button>
                </div>
                
                {generatedPrescription && (
                    <div className="border-t pt-6">
                        <div className="flex border-b mb-4">
                            {(Object.values(PrescriptionTab) as PrescriptionTab[]).map(tab => (
                                <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-2 font-semibold ${activeTab === tab ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-500'}`}>
                                    {tab}
                                </button>
                            ))}
                        </div>
                        {activeTab === PrescriptionTab.FORMAL && (
                            <div className="space-y-4 p-2 text-sm">
                                {generatedPrescription.medications.map((med, i) => <p key={i}><strong>{med.name}:</strong> {med.dosage}. {med.instructions}</p>)}
                                {generatedPrescription.tests.map((test, i) => <p key={i}><strong>Test:</strong> {test.name}. Reason: {test.reason}</p>)}
                                <p><strong>Advice:</strong> {generatedPrescription.generalAdvice}</p>
                            </div>
                        )}
                         {activeTab === PrescriptionTab.EDUCATION && (
                            <div className="space-y-4 p-2 text-sm bg-blue-50 rounded-lg">
                                {generatedPrescription.medications.map((med, i) => <div key={i}><strong>About {med.name}:</strong> <p className="pl-2">{med.education} <strong>Tip:</strong> {med.adherenceTips}</p></div>)}
                                {generatedPrescription.tests.map((test, i) => <div key={i}><strong>About the {test.name}:</strong><p className="pl-2">{test.education}</p></div>)}
                            </div>
                        )}
                        <div className="mt-6 flex gap-4">
                           <button onClick={() => setIsFeedbackModalOpen(true)} className="w-full bg-slate-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-slate-700 transition-colors">Finish Visit</button>
                           <button onClick={handleFinishAndOrder} className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors">Finish & Order Meds/Tests</button>
                        </div>
                    </div>
                )}
            </div>
            
            <Modal isOpen={isDdxModalOpen} onClose={() => setIsDdxModalOpen(false)} title="Differential Diagnosis Assistant">
                {isLoading.ddx ? <LoadingSpinner text="Analyzing..." /> : (
                    <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                            {ddxItems.map((item, i) => (
                                <button key={i} onClick={() => handleSelectDdx(item)} className={`p-3 rounded-lg text-left border-2 ${selectedDdx?.condition === item.condition ? 'bg-blue-100 border-blue-500' : 'bg-white hover:bg-slate-50 border-slate-200'}`}>
                                    <p className="font-semibold text-blue-800">{item.condition}</p>
                                    <p className="text-xs text-slate-600 mt-1">{item.rationale}</p>
                                </button>
                            ))}
                        </div>
                        {isLoading.ddxAction && <LoadingSpinner text="Fetching suggestions..." />}
                        {selectedDdx && ddxActions && (
                            <div className="p-4 bg-slate-50 rounded-lg border mt-4">
                                <h4 className="font-bold text-slate-700 mb-2">Suggested Actions for {selectedDdx.condition}</h4>
                                <div className="space-y-3 text-sm">
                                    {ddxActions.suggestedMedications.length > 0 && <div>
                                        <h5 className="font-semibold">Medications:</h5>
                                        <ul className="list-disc pl-5">
                                            {ddxActions.suggestedMedications.map((med, i) => <li key={i}>{med.name} ({med.typicalDosage}) - {med.typicalInstructions}</li>)}
                                        </ul>
                                    </div>}
                                    {ddxActions.suggestedTests.length > 0 && <div>
                                        <h5 className="font-semibold">Tests:</h5>
                                        <ul className="list-disc pl-5">
                                             {ddxActions.suggestedTests.map((test, i) => <li key={i}>{test.name} - {test.reason}</li>)}
                                        </ul>
                                    </div>}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </Modal>
            
            <FeedbackModal
                isOpen={isFeedbackModalOpen}
                onClose={() => setIsFeedbackModalOpen(false)}
                onSubmit={handleFeedbackSubmit}
            />
        </div>
    );
};

export default DoctorPatientViewStage;