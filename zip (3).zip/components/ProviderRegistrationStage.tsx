import React from 'react';
import { useAppStore } from '../store/appStore';

const ProviderRegistrationStage: React.FC = () => {
  const { goBack } = useAppStore();

  return (
    <div className="max-w-xl mx-auto p-8 bg-white rounded-lg shadow-lg text-center">
      <h2 className="text-2xl font-bold text-slate-800">Provider Registration</h2>
      <p className="text-slate-600 mt-2 mb-6">
        This component is a placeholder for a provider registration flow.
        The main onboarding flow is handled by the "Marketplace Onboarding" form.
      </p>
      <button
        onClick={goBack}
        className="px-6 py-3 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors"
      >
        Go Back
      </button>
    </div>
  );
};

export default ProviderRegistrationStage;
