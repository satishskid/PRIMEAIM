
import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import * as geminiService from '../services/geminiService';
// FIX: Corrected import path for types.
import { PharmacyProvider } from '../../packages/types/index'; // Using PharmacyProvider as a generic provider type for demo
import LoadingSpinner from './LoadingSpinner';

const LabOrderView = () => {
  const { prescription, patientProfile, goBack, resetEpisode } = useAppStore();
  const [labs, setLabs] = useState<PharmacyProvider[]>([]); // Re-using type for simplicity
  const [isLoading, setIsLoading] = useState(false);
  const [broadcastStatus, setBroadcastStatus] = useState<string | null>(null);

  useEffect(() => {
    // In a real app, you'd have a specific service function to list labs
    // geminiService.listLabs().then(setLabs);
    console.log("Fetching labs (placeholder)...");
  }, []);
  
  const labTests = prescription?.tests.filter(t => t.name) || [];

  const handleBroadcastOrder = async () => {
    if (!prescription || !patientProfile || labTests.length === 0) return;
    setIsLoading(true);
    setBroadcastStatus(null);
    try {
      // This would be a different backend endpoint, e.g., /api/orders/broadcast/lab
      // const result = await geminiService.broadcastLabOrder(patientProfile, prescription);
      // setBroadcastStatus(`${result.message} Order ID: ${result.orderId}`);
      
      // Mocking the result for the demo
      await new Promise(resolve => setTimeout(resolve, 1500));
      const mockOrderId = `LAB-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      setBroadcastStatus(`Successfully broadcasted lab order to network. Order ID: ${mockOrderId}`);

    } catch (error: any) {
      setBroadcastStatus(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  if (!prescription || labTests.length === 0) {
    return (
      <div className="text-center p-8">
        <p className="text-slate-600">No lab tests were prescribed in this visit.</p>
        <button onClick={resetEpisode} className="mt-4 px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors">
            Finish & Go Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-2xl font-bold text-center mb-4">Lab Test Order Fulfillment</h2>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h3 className="font-bold text-lg mb-2">Prescribed Tests</h3>
        <ul className="list-disc pl-5 space-y-1 text-slate-700">
          {labTests.map((test, i) => (
            <li key={i}>{test.name} - Reason: {test.reason}</li>
          ))}
        </ul>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="font-bold text-lg mb-2">Lab Network</h3>
        <p className="text-sm text-slate-600 mb-4">Your lab order will be sent to our network of certified diagnostic labs. You can choose the best option for home collection or a center visit based on price and availability.</p>
        
        {isLoading && <LoadingSpinner text="Broadcasting lab order..." />}

        {!isLoading && broadcastStatus && (
          <div className={`p-4 rounded-lg my-4 text-center ${broadcastStatus.startsWith('Error') ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
            <p>{broadcastStatus}</p>
          </div>
        )}
        
        {!broadcastStatus ? (
             <button
                onClick={handleBroadcastOrder}
                disabled={isLoading}
                className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:bg-slate-400"
              >
                Find Best Lab for Tests
              </button>
        ): (
             <button
                onClick={resetEpisode}
                className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Finish & Go Home
              </button>
        )}
      </div>

    </div>
  );
};

export default LabOrderView;