
import React from 'react';
import { useAppStore } from '../store/appStore';
// FIX: Corrected import path
import { Icons } from '../constants';

const MarketplaceConfirmationStage: React.FC = () => {
    const { resetEpisode, lastProviderApplication } = useAppStore();

    return (
        <div className="max-w-2xl mx-auto p-8 bg-white rounded-lg shadow-lg text-center">
            <Icons.Task className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Application Submitted!</h2>
            <p className="text-slate-600 mb-6">
                Thank you, <span className="font-semibold">{lastProviderApplication?.businessName || 'Provider'}</span>. 
                Your application has been received. Our team will review it and contact you at 
                <span className="font-semibold">{lastProviderApplication?.contactEmail || 'your email'}</span> within 3-5 business days.
            </p>
            <button
                onClick={resetEpisode}
                className="px-8 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors"
            >
                Back to Home
            </button>
        </div>
    );
};

export default MarketplaceConfirmationStage;