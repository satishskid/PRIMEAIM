
import React from 'react';
import { useAppStore } from '../store/appStore';
// FIX: Corrected import path for types
import { Episode } from '../../packages/types/index';
import { Icons } from '../constants';

const EpisodeCard: React.FC<{ episode: Episode }> = ({ episode }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200">
      <p className="font-bold text-slate-800">{new Date(episode.date).toLocaleDateString()}</p>
      <p className="text-sm text-slate-500 mb-2">Patient: {episode.patientName || 'N/A'}</p>
      <div className="space-y-1 text-sm">
        <p><strong className="text-slate-600">Symptoms:</strong> {episode.initialSymptomsSummary}</p>
        <p><strong className="text-slate-600">Assessment:</strong> {episode.provisionalDiagnosisSummary}</p>
        <p><strong className="text-slate-600">Clinic:</strong> {episode.clinicName || 'N/A'}</p>
        {episode.prescriptionSummary && <p><strong className="text-slate-600">Plan:</strong> {episode.prescriptionSummary}</p>}
      </div>
    </div>
  );
};

const InteractionHistoryView: React.FC = () => {
  const { episodes, goBack, clearHistory } = useAppStore();
  
  const handleClearHistory = () => {
    if(window.confirm("Are you sure you want to delete all interaction history? This cannot be undone.")) {
        clearHistory();
    }
  }

  return (
    <div className="max-w-3xl mx-auto">
       <div className="flex justify-between items-center mb-6">
            <div>
                 <h2 className="text-2xl font-bold text-slate-800">Interaction History</h2>
                 <p className="text-slate-500">Review your past symptom checks and consultations.</p>
            </div>
            <button onClick={goBack} className="px-4 py-2 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors">
              Back
            </button>
       </div>
      
      {episodes.length > 0 ? (
        <div className="space-y-4">
          {episodes.map(ep => <EpisodeCard key={ep.id} episode={ep} />)}
          <div className="text-center pt-4">
             <button onClick={handleClearHistory} className="text-sm text-red-600 hover:text-red-800 transition-colors">
                Clear All History
             </button>
          </div>
        </div>
      ) : (
         <div className="text-center py-12 px-4 bg-white rounded-lg shadow-sm">
          <Icons.InformationCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600 font-medium">No past interactions found.</p>
          <p className="text-sm text-slate-500">Your symptom checks will appear here after you complete them.</p>
        </div>
      )}
    </div>
  );
};

export default InteractionHistoryView;