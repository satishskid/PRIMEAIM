
import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import * as clinicService from '../services/clinicService';
// FIX: Corrected import path for types.
import { Clinic } from '../../packages/types/index';
import LoadingSpinner from './LoadingSpinner';
import { Icons } from '../constants';

const ClinicSelectionStage: React.FC = () => {
    const { provisionalDiagnosis, setClinic, goToBooking, goBack } = useAppStore();
    const [clinics, setClinics] = useState<Clinic[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const loadClinics = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const fetchedClinics = await clinicService.fetchClinics(provisionalDiagnosis?.condition || null);
                setClinics(fetchedClinics);
            } catch (err) {
                setError('Failed to load available clinics. Please try again.');
            } finally {
                setIsLoading(false);
            }
        };

        loadClinics();
    }, [provisionalDiagnosis]);

    const handleSelectClinic = (clinic: Clinic) => {
        setClinic(clinic);
        goToBooking();
    };

    if (isLoading) {
        return <LoadingSpinner text="Finding suitable clinics..." />;
    }

    if (error) {
        return <div className="text-center text-red-500">{error}</div>;
    }

    return (
        <div className="max-w-4xl mx-auto p-4">
            <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-slate-800">Clinic Recommendations</h2>
                <p className="text-slate-600 mt-2">
                    Based on your provisional assessment of <strong className="text-slate-700">"{provisionalDiagnosis?.condition || 'your symptoms'}"</strong>, here are some recommended clinics.
                </p>
            </div>

            <div className="space-y-4">
                {clinics.length > 0 ? (
                    clinics.map(clinic => (
                        <div key={clinic.id} className="bg-white p-6 rounded-lg shadow-md border border-slate-200">
                            <div className="flex flex-col sm:flex-row justify-between items-start">
                                <div>
                                    <h3 className="text-xl font-bold text-blue-800">{clinic.name}</h3>
                                    <p className="text-slate-600"><strong>Specialties:</strong> {clinic.mainSpecialties.join(', ')}</p>
                                    <p className="text-sm text-slate-500">{clinic.locationDetails.addressLine1}, {clinic.locationDetails.city}</p>
                                </div>
                                <div className="mt-4 sm:mt-0 text-right">
                                    <div className="flex items-center justify-end gap-1 font-bold text-lg text-amber-500">
                                       <span>{clinic.systemCalculatedRating.score.toFixed(1)}</span>
                                       <Icons.Sparkles className="w-5 h-5"/>
                                    </div>
                                    <p className="text-xs text-slate-500">System Rating</p>
                                </div>
                            </div>
                            <div className="border-t my-4"></div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                <div>
                                    <p className="text-slate-500">{clinic.systemCalculatedRating.rationale}</p>
                                </div>
                                <div>
                                    <p><strong>Lead Doctor:</strong> {clinic.doctorName}</p>
                                    <p><strong>Hours:</strong> {clinic.operationalHours}</p>
                                    <div className="flex flex-wrap gap-2 mt-2">
                                        {clinic.bookingSystemFeatures.map(feature => (
                                            <span key={feature} className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">{feature}</span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                             <button
                                onClick={() => handleSelectClinic(clinic)}
                                className="mt-4 w-full sm:w-auto float-right bg-blue-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-blue-700 transition-colors"
                            >
                                Select & Book
                            </button>
                        </div>
                    ))
                ) : (
                    <div className="text-center p-8 bg-white rounded-lg shadow">
                        <p>No clinics found matching your needs at this time.</p>
                    </div>
                )}
            </div>
            
            <div className="text-center mt-8">
                <button onClick={goBack} className="text-slate-600 hover:text-slate-800 transition-colors">
                    &larr; Back to Symptom Checker
                </button>
            </div>
        </div>
    );
};

export default ClinicSelectionStage;