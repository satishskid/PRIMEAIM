import React from 'react';

const ProviderDashboardStage: React.FC = () => {
  return (
    <div className="text-center p-8">
      <h2 className="text-2xl font-bold">Provider Dashboard</h2>
      <p className="text-slate-600 mt-2">This component is a placeholder for a future feature.</p>
      <p className="text-slate-500 text-sm">
        A logged-in provider would see their dashboard here, with incoming orders, patient messages, and analytics.
      </p>
    </div>
  );
};

export default ProviderDashboardStage;
