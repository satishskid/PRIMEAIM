import React, { useState } from 'react';
import { useAppStore } from '../store/appStore';
// FIX: Corrected import path for types.
import { MarketplaceApplication, BusinessType } from '../../packages/types/index';
import * as adminService from '../services/adminService';
import { Icons } from '../constants';
import LoadingSpinner from './LoadingSpinner';

const MarketplaceOnboardingFormStage: React.FC = () => {
    const { goToMarketplaceConfirmation, goBack, setLastProviderApplication } = useAppStore();
    const [formData, setFormData] = useState<Partial<MarketplaceApplication>>({
        businessType: BusinessType.CLINIC,
        attestedCompliance: false,
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setIsLoading(true);
        try {
            // Basic validation
            if (!formData.businessName || !formData.contactEmail || !formData.address || !formData.contactPhone) {
                 throw new Error("Please fill out all required fields.");
            }
            if (!formData.attestedCompliance) {
                 throw new Error("You must attest to compliance.");
            }

            const applicationData = formData as MarketplaceApplication;
            const result = await adminService.registerProvider(applicationData);
            setLastProviderApplication(result.application);
            goToMarketplaceConfirmation();
        } catch (err: any) {
            setError(err.message || 'An error occurred during submission.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-2xl mx-auto p-8 bg-white rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold text-slate-800 text-center mb-2">Provider Onboarding</h2>
            <p className="text-center text-slate-500 mb-6">Tell us about your business to get started.</p>

            <form onSubmit={handleSubmit} className="space-y-6">
                <fieldset className="p-4 border rounded-md">
                    <legend className="px-2 font-semibold text-slate-700">Business Details</legend>
                    <div className="space-y-4">
                         <div>
                            <label htmlFor="businessName" className="block text-sm font-medium text-slate-700">Business Name</label>
                            <input type="text" name="businessName" id="businessName" onChange={handleChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm"/>
                        </div>
                        <div>
                            <label htmlFor="address" className="block text-sm font-medium text-slate-700">Full Address</label>
                            <textarea name="address" id="address" rows={2} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm"/>
                        </div>
                        <div>
                            <label htmlFor="businessType" className="block text-sm font-medium text-slate-700">Business Type</label>
                            <select name="businessType" id="businessType" value={formData.businessType} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm">
                                <option value={BusinessType.CLINIC}>Clinic</option>
                                <option value={BusinessType.PHARMACY}>Pharmacy</option>
                                <option value={BusinessType.LAB}>Lab</option>
                            </select>
                        </div>
                    </div>
                </fieldset>

                <fieldset className="p-4 border rounded-md">
                    <legend className="px-2 font-semibold text-slate-700">Contact Information</legend>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="contactEmail" className="block text-sm font-medium text-slate-700">Contact Email</label>
                            <input type="email" name="contactEmail" id="contactEmail" onChange={handleChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm"/>
                        </div>
                         <div>
                            <label htmlFor="contactPhone" className="block text-sm font-medium text-slate-700">Contact Phone</label>
                            <input type="tel" name="contactPhone" id="contactPhone" onChange={handleChange} required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm"/>
                        </div>
                    </div>
                </fieldset>

                <fieldset className="p-4 border rounded-md">
                     <legend className="px-2 font-semibold text-slate-700">Compliance</legend>
                    <div className="flex items-start mt-2">
                        <input type="checkbox" name="attestedCompliance" id="attestedCompliance" checked={!!formData.attestedCompliance} onChange={handleChange} className="h-4 w-4 text-blue-600 border-slate-300 rounded mt-1"/>
                        <label htmlFor="attestedCompliance" className="ml-3 block text-sm text-slate-900">I attest that this business complies with all local and national healthcare regulations required to operate.</label>
                    </div>
                </fieldset>

                {error && <p className="text-red-500 text-sm text-center">{error}</p>}

                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                    <button type="button" onClick={goBack} disabled={isLoading} className="w-full px-6 py-3 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300">Back</button>
                    <button type="submit" disabled={isLoading} className="w-full px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2 disabled:bg-slate-400">
                        {isLoading ? <LoadingSpinner size="sm"/> : <Icons.Send className="w-5 h-5"/>}
                        Submit Application
                    </button>
                </div>
            </form>
        </div>
    );
};

export default MarketplaceOnboardingFormStage;