import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import * as adminService from '../services/adminService';
import { AdminDashboardData, MarketplaceApplication, UserStatus } from '../../packages/types';
import LoadingSpinner from './LoadingSpinner';
import { Icons } from '../constants';

const AdminDashboardStage: React.FC = () => {
    const { goBack } = useAppStore();
    const [data, setData] = useState<AdminDashboardData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            const dashboardData = await adminService.getAdminDashboardData();
            setData(dashboardData);
        } catch (err) {
            setError('Failed to load admin data.');
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleUpdateStatus = async (id: string, status: 'APPROVED' | 'REJECTED') => {
        try {
            await adminService.updateApplicationStatus(id, status);
            fetchData(); // Refresh data after update
        } catch (err) {
            alert('Failed to update status.');
        }
    };

    if (isLoading) {
        return <LoadingSpinner text="Loading admin dashboard..." />;
    }

    if (error) {
        return <div className="text-center text-red-500">{error}</div>;
    }

    return (
        <div className="max-w-6xl mx-auto p-4">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-slate-800">Admin Dashboard</h2>
                <button onClick={goBack} className="px-4 py-2 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors">
                    Back to Home
                </button>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <div className="bg-white p-4 rounded-lg shadow">
                    <h3 className="text-slate-500">Submitted Applications</h3>
                    <p className="text-3xl font-bold">{data?.applicationCounts?.SUBMITTED || 0}</p>
                </div>
                 <div className="bg-white p-4 rounded-lg shadow">
                    <h3 className="text-slate-500">Approved Providers</h3>
                    <p className="text-3xl font-bold">{data?.applicationCounts?.APPROVED || 0}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                    <h3 className="text-slate-500">Total Clinics</h3>
                    <p className="text-3xl font-bold">{data?.providerCounts?.CLINIC || 0}</p>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                    <h3 className="text-slate-500">Total Pharmacies</h3>
                    <p className="text-3xl font-bold">{data?.providerCounts?.PHARMACY || 0}</p>
                </div>
            </div>

            {/* Recent Applications Table */}
            <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-xl font-bold mb-4">Recent Provider Applications</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-slate-50 text-slate-600">
                            <tr>
                                <th className="p-3">Business Name</th>
                                <th className="p-3">Type</th>
                                <th className="p-3">Email</th>
                                <th className="p-3">Status</th>
                                <th className="p-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data?.recentApplications.map((app) => (
                                <tr key={app.id} className="border-b">
                                    <td className="p-3 font-medium">{app.businessName}</td>
                                    <td className="p-3">{app.businessType}</td>
                                    <td className="p-3">{app.contactEmail}</td>
                                    <td className="p-3">
                                        <span className={`px-2 py-1 rounded-full text-xs ${app.status === 'APPROVED' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                                            {app.status}
                                        </span>
                                    </td>
                                    <td className="p-3">
                                        {app.status === 'SUBMITTED' && (
                                            <div className="flex gap-2">
                                                <button onClick={() => handleUpdateStatus(app.id, 'APPROVED')} className="text-green-600 hover:text-green-800">Approve</button>
                                                <button onClick={() => handleUpdateStatus(app.id, 'REJECTED')} className="text-red-600 hover:text-red-800">Reject</button>
                                            </div>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboardStage;
