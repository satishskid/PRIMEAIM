
import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import * as geminiService from '../services/geminiService';
// FIX: Corrected import path for types
import { PharmacyProvider } from '../../packages/types/index';
import LoadingSpinner from './LoadingSpinner';

const PharmacyOrderView = () => {
  const { prescription, patientProfile, goBack, resetEpisode } = useAppStore();
  const [pharmacies, setPharmacies] = useState<PharmacyProvider[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [broadcastStatus, setBroadcastStatus] = useState<string | null>(null);

  useEffect(() => {
    geminiService.listPharmacies().then(setPharmacies);
  }, []);

  const handleBroadcastOrder = async () => {
    if (!prescription || !patientProfile) return;
    setIsLoading(true);
    setBroadcastStatus(null);
    try {
      const result = await geminiService.broadcastPharmacyOrder(patientProfile, prescription);
      setBroadcastStatus(`${result.message} Order ID: ${result.orderId}`);
      // In a real app, we would now poll for bids or use websockets.
      // For this demo, we just show success and allow the user to finish.
    } catch (error: any) {
      setBroadcastStatus(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  if (!prescription) {
    return (
      <div className="text-center">
        <p>No prescription to order.</p>
        <button onClick={goBack}>Go Back</button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-2xl font-bold text-center mb-4">Pharmacy Order Fulfillment</h2>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h3 className="font-bold text-lg mb-2">Prescription Details</h3>
        <ul className="list-disc pl-5 space-y-1 text-slate-700">
          {prescription.medications.map((med, i) => (
            <li key={i}>{med.name} - {med.dosage}</li>
          ))}
          {prescription.tests.map((test, i) => (
            <li key={i}>Lab Test: {test.name}</li>
          ))}
        </ul>
        <p className="mt-4 text-sm text-slate-600"><strong>Advice:</strong> {prescription.generalAdvice}</p>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="font-bold text-lg mb-2">Order Fulfillment Network</h3>
        <p className="text-sm text-slate-600 mb-4">Your prescription will be securely broadcasted to our network of {pharmacies.length} trusted pharmacies. They will bid to fill your order based on price, speed, and quality.</p>
        
        {isLoading && <LoadingSpinner text="Broadcasting order..." />}

        {!isLoading && broadcastStatus && (
          <div className={`p-4 rounded-lg my-4 text-center ${broadcastStatus.startsWith('Error') ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
            <p>{broadcastStatus}</p>
          </div>
        )}
        
        {!broadcastStatus ? (
             <button
                onClick={handleBroadcastOrder}
                disabled={isLoading}
                className="w-full bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:bg-slate-400"
              >
                Find Best Price & Delivery
              </button>
        ): (
             <button
                onClick={resetEpisode}
                className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Finish & Go Home
              </button>
        )}
      </div>

    </div>
  );
};

export default PharmacyOrderView;