
import React, { useState } from 'react';
import { useAppStore } from '../store/appStore';
import { Icons } from '../constants';

const BookingStage: React.FC = () => {
    const { appointment, setAppointmentDateTime, goToDoctorPatientView, goBack } = useAppStore();
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 16)); // Default to now
    const [error, setError] = useState<string | null>(null);

    if (!appointment) {
        return <div className="text-center p-8">Error: No appointment details found. Please go back.</div>;
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const now = new Date();
        const chosenDate = new Date(selectedDate);
        if (chosenDate < now) {
            setError("Please select a future date and time for your appointment.");
            return;
        }
        setError(null);
        setAppointmentDateTime(chosenDate.toISOString());
        goToDoctorPatientView();
    };

    const { clinic, provisionalDiagnosis, patientProfile, patientSymptoms } = appointment;

    return (
        <div className="max-w-2xl mx-auto p-8 bg-white rounded-lg shadow-lg">
            <h2 className="text-3xl font-bold text-slate-800 text-center mb-4">Confirm Your Booking</h2>
            <p className="text-center text-slate-500 mb-8">
                You are about to start a simulated consultation with <strong>{clinic.doctorName}</strong> at <strong>{clinic.name}</strong>.
            </p>

            <div className="space-y-4 p-6 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                    <h3 className="font-semibold text-slate-700">Patient</h3>
                    <p className="text-slate-600">{patientProfile?.name || 'N/A'}</p>
                </div>
                 <div>
                    <h3 className="font-semibold text-slate-700">Chief Complaint</h3>
                    <p className="text-slate-600">{patientSymptoms}</p>
                </div>
                <div>
                    <h3 className="font-semibold text-slate-700">Provisional Diagnosis</h3>
                    <p className="text-slate-600">{provisionalDiagnosis?.condition || 'N/A'}</p>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="mt-6">
                <label htmlFor="appointment-time" className="block text-lg font-medium text-slate-700 mb-2">
                    Select Appointment Time
                </label>
                <input
                    type="datetime-local"
                    id="appointment-time"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                />
                 {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                
                 <div className="flex flex-col sm:flex-row gap-4 mt-8">
                    <button
                      type="button"
                      onClick={goBack}
                      className="w-full px-6 py-3 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors"
                    >
                      Back to Clinic Selection
                    </button>
                    <button
                      type="submit"
                      className="w-full px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <Icons.Task className="w-5 h-5"/>
                      Confirm and Start Consultation
                    </button>
                </div>
            </form>
        </div>
    );
};

export default BookingStage;
