import React from 'react';
import { useAppStore } from '../store/appStore';
import { Icons } from '../constants';

const ApiKeyStage: React.FC = () => {
  const { goToWelcome } = useAppStore();

  return (
    <div className="max-w-xl mx-auto p-6 bg-white rounded-lg shadow-lg text-center">
      <Icons.InformationCircle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Configuration Note</h2>
      <p className="text-slate-600 mb-6">
        This application is designed to securely access the Gemini API key from the server's environment variables (`process.env.API_KEY`).
      </p>
      <p className="text-sm text-slate-500 bg-slate-50 p-3 rounded-md">
        There is no need to enter an API key in the user interface. Please ensure the backend is configured correctly.
      </p>
      <button
        onClick={goToWelcome}
        className="mt-6 w-full px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors"
      >
        Proceed to Application
      </button>
    </div>
  );
};

export default ApiKeyStage;
