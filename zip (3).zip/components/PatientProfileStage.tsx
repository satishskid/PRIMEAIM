import React, { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
// FIX: Corrected import path for types
import { PatientProfile } from '../../packages/types/index';
import { Icons } from '../constants';

const PatientProfileStage: React.FC = () => {
  const { setPatientProfile, goToSymptomInput, patientProfile, goBack } = useAppStore();
  const [profile, setProfile] = useState<PatientProfile>(patientProfile || {});
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile.name?.trim()) {
        setError("Name is required to personalize your experience.");
        return;
    }
    setError(null);
    setPatientProfile(profile);
    goToSymptomInput();
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold text-slate-800 text-center mb-2">Personalizing Your Assessment</h2>
      <p className="text-center text-slate-500 mb-6">Let's get some basic information to help our AI provide a more accurate assessment. This is optional but recommended.</p>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-700">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={profile.name || ''}
            onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., John Doe"
          />
        </div>
         <div>
          <label htmlFor="age" className="block text-sm font-medium text-slate-700">Age</label>
          <input
            type="text"
            id="age"
            name="age"
            value={profile.age || ''}
            onChange={handleChange}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., 35"
          />
        </div>
        <div>
          <label htmlFor="pastHistory" className="block text-sm font-medium text-slate-700">Past Medical History (Optional)</label>
          <p className="text-xs text-slate-500 mb-1">Helps the AI understand your health context.</p>
          <textarea
            id="pastHistory"
            name="pastHistory"
            value={profile.pastHistory || ''}
            onChange={handleChange}
            rows={3}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 custom-scrollbar"
            placeholder="e.g., Asthma, high blood pressure"
          />
        </div>
        <div>
          <label htmlFor="habits" className="block text-sm font-medium text-slate-700">Lifestyle Habits (Optional)</label>
          <p className="text-xs text-slate-500 mb-1">Relevant habits can provide useful clues.</p>
          <textarea
            id="habits"
            name="habits"
            value={profile.habits || ''}
            onChange={handleChange}
            rows={2}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 custom-scrollbar"
            placeholder="e.g., Regular exercise, non-smoker"
          />
        </div>
        
        {error && <p className="text-red-500 text-sm">{error}</p>}
        
        <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button
              type="button"
              onClick={goBack}
              className="w-full px-6 py-3 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors"
            >
              Back to Welcome
            </button>
            <button
              type="submit"
              className="w-full px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Icons.ChatBubble className="w-5 h-5"/>
              Continue to Symptom Checker
            </button>
        </div>
      </form>
    </div>
  );
};

export default PatientProfileStage;