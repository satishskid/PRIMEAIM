import React from 'react';
import { useAppStore } from '../store/appStore';
import { Icons } from '../constants';

const WelcomeStage: React.FC = () => {
    const { startSymptomChecker, viewHistory, goToMarketplaceWelcome, goToAdmin } = useAppStore();

    return (
        <div className="max-w-3xl mx-auto p-8 bg-white rounded-lg shadow-lg text-center">
            <Icons.Sparkles className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Your Smart Health Journey Starts Here</h2>
            <p className="text-slate-600 mb-8 max-w-2xl mx-auto">
                Get clarity on your health concerns. Our AI-powered assistant helps you understand your symptoms, connects you with trusted local clinics, and empowers you to take the next step with confidence.
            </p>

            {/* Value Propositions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left my-10">
                <div className="p-4">
                    <Icons.ChatBubble className="w-8 h-8 text-blue-500 mb-2"/>
                    <h3 className="font-semibold text-slate-700">Understand Your Symptoms</h3>
                    <p className="text-sm text-slate-600">Our AI engages in a natural conversation to help pinpoint potential causes.</p>
                </div>
                <div className="p-4">
                    <Icons.Search className="w-8 h-8 text-blue-500 mb-2"/>
                    <h3 className="font-semibold text-slate-700">Find Trusted Care</h3>
                    <p className="text-sm text-slate-600">We recommend top-rated, vetted clinics that are right for your needs.</p>
                </div>
                <div className="p-4">
                    <Icons.Task className="w-8 h-8 text-blue-500 mb-2"/>
                    <h3 className="font-semibold text-slate-700">Get a Clear Plan</h3>
                    <p className="text-sm text-slate-600">Receive a provisional assessment and clear next steps in minutes.</p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Patient Actions */}
                <div className="p-6 bg-slate-50 rounded-lg">
                    <h3 className="font-bold text-lg text-slate-700 mb-4">For Patients</h3>
                    <div className="space-y-3">
                         <button
                            onClick={startSymptomChecker}
                            className="w-full px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                        >
                            <Icons.ChatBubble className="w-5 h-5"/>
                            Start Symptom Checker
                        </button>
                        <button
                            onClick={viewHistory}
                            className="w-full px-6 py-3 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors"
                        >
                            View Past Interactions
                        </button>
                    </div>
                </div>
                {/* Provider/Admin Actions */}
                <div className="p-6 bg-slate-50 rounded-lg">
                    <h3 className="font-bold text-lg text-slate-700 mb-4">For Partners</h3>
                    <div className="space-y-3">
                         <button
                            onClick={goToMarketplaceWelcome}
                            className="w-full px-6 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition-colors"
                        >
                           I'm a Provider
                        </button>
                         <button
                            onClick={goToAdmin}
                            className="w-full px-6 py-3 bg-slate-600 text-white font-semibold rounded-lg hover:bg-slate-700 transition-colors"
                        >
                            Admin Panel
                        </button>
                    </div>
                </div>
            </div>

            <div className="mt-8">
                <p className="text-xs text-slate-500">
                    <strong>Your data is private and secure.</strong> We will never share your personal health information without your consent.
                </p>
            </div>
        </div>
    );
};

export default WelcomeStage;