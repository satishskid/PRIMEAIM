import React from 'react';
import { useAppStore } from '../store/appStore';
// FIX: Corrected import path
import { Icons } from '../constants';

const MarketplaceWelcomeStage: React.FC = () => {
    const { startProviderOnboarding, goBack } = useAppStore();

    return (
        <div className="max-w-3xl mx-auto p-8 bg-white rounded-lg shadow-lg text-center">
            <Icons.Sparkles className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Grow Your Practice. Delight Your Patients.</h2>
            <p className="text-slate-600 mb-6">
                Join our network to connect with qualified patients, streamline your workflow with AI-powered tools, and focus on what you do best—delivering exceptional care.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left my-8">
                <div className="p-4 bg-slate-50 rounded-lg border">
                    <h3 className="font-semibold text-slate-700">Receive Qualified Patient Leads</h3>
                    <p className="text-sm text-slate-600">Connect with local patients whose needs match your specialties.</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border">
                    <h3 className="font-semibold text-slate-700">AI-Powered Efficiency</h3>
                    <p className="text-sm text-slate-600">Save time with AI-generated clinical notes, prescriptions, and ddx suggestions.</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border">
                    <h3 className="font-semibold text-slate-700">Simple & Secure</h3>
                    <p className="text-sm text-slate-600">Onboard in minutes and manage interactions through a single, compliant dashboard.</p>
                </div>
            </div>
            
            <blockquote className="my-8 p-4 bg-slate-100 border-l-4 border-blue-500 text-left">
                <p className="text-slate-700 italic">"Joining this network was a game-changer. Our administrative overhead has dropped by 20%, and we're seeing more relevant patient cases than ever before."</p>
                <cite className="block text-sm text-slate-600 font-semibold mt-2 not-italic">— Dr. Anya Sharma, City Central Clinic</cite>
            </blockquote>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                 <button onClick={goBack} className="px-8 py-3 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors">
                   I'm a Patient
                </button>
                <button
                    onClick={startProviderOnboarding}
                    className="px-8 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-colors"
                >
                    Start Onboarding
                </button>
            </div>
        </div>
    );
};

export default MarketplaceWelcomeStage;