import React from 'react';
import Modal from './Modal';
import { useAppStore } from '../store/appStore';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { isAdmin, logout } = useAppStore();

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Settings">
      <div className="p-4 text-center">
        <p className="text-slate-600">
          This is a placeholder for future application settings.
        </p>
        <p className="text-sm text-slate-500 mt-2">
          Configuration, such as API keys, is managed on the server.
        </p>

        {isAdmin && (
          <button
            onClick={() => {
              logout();
              onClose();
            }}
            className="mt-6 w-full px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors"
          >
            Logout Admin
          </button>
        )}
      </div>
    </Modal>
  );
};

export default SettingsModal;