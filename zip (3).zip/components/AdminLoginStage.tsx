import React, { useState } from 'react';
import { useAppStore, AppStage } from '../store/appStore';
import * as authService from '../services/authService';
import { Icons } from '../constants';
import LoadingSpinner from './LoadingSpinner';

const AdminLoginStage: React.FC = () => {
    const { setAuth, goToStage, goBack } = useAppStore();
    const [email, setEmail] = useState('admin@pca.com');
    const [password, setPassword] = useState('admin123');
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setIsLoading(true);
        try {
            const response = await authService.login({ email, password });
            if (response.user?.isAdmin) {
                setAuth(response.token, true);
                goToStage(AppStage.ADMIN_DASHBOARD);
            } else {
                setError('Access denied. This account does not have admin privileges.');
                authService.logout(); // Clear token if a non-admin user logs in here
            }
        } catch (err: any) {
            setError(err.data?.error || 'Login failed. Please check your credentials.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-md mx-auto p-8 bg-white rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold text-slate-800 text-center mb-2">Admin Login</h2>
            <p className="text-center text-slate-500 mb-6">Enter your credentials to access the dashboard.</p>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-700">Email</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                </div>
                <div>
                    <label htmlFor="password" className="block text-sm font-medium text-slate-700">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                </div>
                {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                <div className="pt-4 space-y-3">
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full px-6 py-3 bg-slate-800 text-white font-bold rounded-lg hover:bg-slate-900 transition-colors flex items-center justify-center gap-2 disabled:bg-slate-400"
                    >
                        {isLoading ? <LoadingSpinner size="sm" /> : 'Login'}
                    </button>
                    <button
                        type="button"
                        onClick={goBack}
                        disabled={isLoading}
                        className="w-full px-6 py-2 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition-colors"
                    >
                        Back to Home
                    </button>
                </div>
            </form>
        </div>
    );
};

export default AdminLoginStage;
