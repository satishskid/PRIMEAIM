
import React, { useState } from 'react';
// FIX: Corrected import path for types
import { Task } from '../../packages/types/index';
import { Icons } from '../constants';

interface TaskListProps {
  tasks: Task[];
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;
}

const TaskItem: React.FC<{ task: Task; onUpdate: (task: Task) => void; onDelete: (id: string) => void; onEdit: (task: Task) => void; }> = ({ task, onUpdate, onDelete, onEdit }) => {
  const handleToggle = () => {
    onUpdate({ ...task, completed: !task.completed });
  };

  const formatDueDate = (dueDateString: string): { text: string, className: string, isPast: boolean } => {
    const dueDate = new Date(dueDateString);
    const now = new Date();
    const isPast = dueDate < now;
    const oneDayInMs = 24 * 60 * 60 * 1000;
    const isUpcoming = dueDate.getTime() - now.getTime() < oneDayInMs && !isPast;
    
    let className = 'text-slate-500';
    if (isPast && !task.completed) {
      className = 'text-red-600 font-semibold';
    } else if (isUpcoming && !task.completed) {
      className = 'text-orange-600 font-semibold';
    }

    const formattedDate = dueDate.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    let prefix = 'Due:';
    if(isPast && !task.completed) prefix = 'Overdue:';
    if(isUpcoming && !task.completed) prefix = 'Upcoming:';

    return { text: `${prefix} ${formattedDate}`, className, isPast };
  };
  
  const dueDateInfo = task.dueDate ? formatDueDate(task.dueDate) : null;

  return (
    <li className={`flex items-start gap-4 p-4 rounded-lg transition-colors duration-200 ${task.completed ? 'bg-slate-50 text-slate-500' : 'bg-white hover:bg-slate-50'}`}>
      <input
        type="checkbox"
        checked={task.completed}
        onChange={handleToggle}
        className="mt-1 h-5 w-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
        aria-labelledby={`task-text-${task.id}`}
      />
      <div className="flex-1">
        <p id={`task-text-${task.id}`} className={`text-slate-800 ${task.completed ? 'line-through' : ''}`}>
          {task.text}
        </p>
         {dueDateInfo && (
          <p className={`text-xs mt-1 ${dueDateInfo.className}`}>
            {dueDateInfo.text}
          </p>
        )}
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onEdit(task)}
          className="p-1 text-slate-500 hover:text-blue-600 transition-colors"
          aria-label={`Edit task: ${task.text}`}
        >
          <Icons.Edit className="w-5 h-5" />
        </button>
        <button
          onClick={() => onDelete(task.id)}
          className="p-1 text-slate-500 hover:text-red-600 transition-colors"
          aria-label={`Delete task: ${task.text}`}
        >
          <Icons.Delete className="w-5 h-5" />
        </button>
      </div>
    </li>
  );
};

const TaskList: React.FC<TaskListProps> = ({ tasks, addTask, updateTask, deleteTask }) => {
  const [newTaskText, setNewTaskText] = useState('');
  const [newDueDate, setNewDueDate] = useState('');
  
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [editingTaskText, setEditingTaskText] = useState('');
  const [editingDueDate, setEditingDueDate] = useState('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskText.trim()) {
      addTask({
        text: newTaskText.trim(),
        completed: false,
        dueDate: newDueDate || undefined,
        notificationSent: false,
      });
      setNewTaskText('');
      setNewDueDate('');
    }
  };

  const handleUpdateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTask && editingTaskText.trim()) {
      const originalDueDate = editingTask.dueDate || '';
      const newDueDateValue = editingDueDate || undefined;
      
      // Reset notification flag if due date has changed to a future date
      const resetNotification = originalDueDate !== newDueDateValue && newDueDateValue && new Date(newDueDateValue) > new Date();

      updateTask({
        ...editingTask,
        text: editingTaskText.trim(),
        dueDate: newDueDateValue,
        ...(resetNotification && { notificationSent: false })
      });
      setEditingTask(null);
      setEditingTaskText('');
      setEditingDueDate('');
    }
  };

  const handleEdit = (task: Task) => {
    setEditingTask(task);
    setEditingTaskText(task.text);
    // Format for datetime-local input which needs 'YYYY-MM-DDTHH:mm'
    setEditingDueDate(task.dueDate ? task.dueDate.slice(0, 16) : '');
  };

  return (
    <div>
      <form onSubmit={editingTask ? handleUpdateTask : handleAddTask} className="mb-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <h2 className="text-lg font-semibold text-slate-700 mb-3">{editingTask ? 'Edit Task' : 'Add a New Task'}</h2>
        <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={editingTask ? editingTaskText : newTaskText}
              onChange={(e) => editingTask ? setEditingTaskText(e.target.value) : setNewTaskText(e.target.value)}
              placeholder="What do you need to do?"
              className="flex-grow p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 transition-shadow"
            />
            <input
              type="datetime-local"
              value={editingTask ? editingDueDate : newDueDate}
              onChange={(e) => editingTask ? setEditingDueDate(e.target.value) : setNewDueDate(e.target.value)}
              className="p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 transition-shadow text-slate-600 text-sm"
              title="Set a due date and time"
            />
            <button
              type="submit"
              className={`px-6 py-3 font-semibold text-white rounded-lg transition-colors shadow flex items-center justify-center ${
                editingTask ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {editingTask ? <Icons.Edit className="w-5 h-5 mr-2" /> : <Icons.Add className="w-5 h-5 mr-2" />}
              {editingTask ? 'Save Changes' : 'Add Task'}
            </button>
            {editingTask && (
                <button
                    type="button"
                    onClick={() => setEditingTask(null)}
                    className="px-4 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-lg transition-colors"
                >
                    Cancel
                </button>
            )}
        </div>
      </form>

      {tasks.length > 0 ? (
        <ul className="space-y-3">
          {tasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              onUpdate={updateTask}
              onDelete={deleteTask}
              onEdit={handleEdit}
            />
          ))}
        </ul>
      ) : (
        <div className="text-center py-8 px-4 bg-slate-50 rounded-lg">
          <Icons.Task className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-600 font-medium">All tasks completed!</p>
          <p className="text-sm text-slate-500">Ready to add a new one?</p>
        </div>
      )}
    </div>
  );
};

export default TaskList;