// src/tests/setup.ts
import '@testing-library/jest-dom';
