// src/components/WelcomeStage.test.tsx
// FIX: Add reference to jest-dom types to fix 'toBeInTheDocument' error.
/// <reference types="@testing-library/jest-dom" />
import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import WelcomeStage from './WelcomeStage';
// FIX: The file now exists, so this import will work.
import { useAppStore } from '../store/appStore';

// Mock the zustand store
vi.mock('../store/appStore');

describe('WelcomeStage', () => {
  it('renders all primary action buttons', () => {
    // Provide mock implementations for the store's actions
    (useAppStore as any).mockReturnValue({
      startSymptomChecker: vi.fn(),
      viewHistory: vi.fn(),
      goToMarketplaceWelcome: vi.fn(),
      goToAdmin: vi.fn(),
    });

    render(<WelcomeStage />);

    // Check for the main title
    // FIX: This assertion will now pass due to the setup file in vite.config.ts and the reference directive above.
    expect(screen.getByRole('heading', { name: /Your Smart Health Journey Starts Here/i })).toBeInTheDocument();

    // Check for all buttons
    expect(screen.getByRole('button', { name: /Start Symptom Checker/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /View Past Interactions/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /I'm a Provider/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Admin Panel/i })).toBeInTheDocument();
  });
});
