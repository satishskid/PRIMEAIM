interface RequestOptions {
    headers?: Record<string, string>;
    responseAs?: 'json' | 'text';
    // Add other options like 'credentials', 'mode', etc., if needed
}

class ApiClient {
    private baseUrl: string;

    constructor(baseUrl: string = '') {
        this.baseUrl = baseUrl;
    }

    private getAuthHeaders(): Record<string, string> {
        const token = localStorage.getItem('authToken');
        if (token) {
            return { Authorization: `Bearer ${token}` };
        }
        return {};
    }

    private async handleResponse<T>(response: Response, responseAs: 'json' | 'text'): Promise<T> {
        if (!response.ok) {
            let errorBody;
            try {
                errorBody = await response.json();
            } catch (e) {
                errorBody = { message: await response.text() };
            }
            const error = new Error(errorBody.message || `HTTP error! status: ${response.status}`);
            (error as any).response = response;
            (error as any).data = errorBody;
            throw error;
        }

        if (responseAs === 'text') {
            return response.text() as Promise<T>;
        }
        return response.json() as Promise<T>;
    }

    async get<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
        const { headers = {}, responseAs = 'json' } = options;
        const authHeaders = this.getAuthHeaders();
        const response = await fetch(`${this.baseUrl}${endpoint}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                ...authHeaders,
                ...headers,
            },
        });
        return this.handleResponse<T>(response, responseAs);
    }

    async post<T>(endpoint: string, body: any, options: RequestOptions = {}): Promise<T> {
        const { headers = {}, responseAs = 'json' } = options;
        const authHeaders = this.getAuthHeaders();
        const response = await fetch(`${this.baseUrl}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                ...authHeaders,
                ...headers,
            },
            body: JSON.stringify(body),
        });
        return this.handleResponse<T>(response, responseAs);
    }

    async put<T>(endpoint: string, body: any, options: RequestOptions = {}): Promise<T> {
        const { headers = {}, responseAs = 'json' } = options;
        const authHeaders = this.getAuthHeaders();
        const response = await fetch(`${this.baseUrl}${endpoint}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                ...authHeaders,
                ...headers,
            },
            body: JSON.stringify(body),
        });
        return this.handleResponse<T>(response, responseAs);
    }
}

export const apiClient = new ApiClient();