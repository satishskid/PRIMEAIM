
// src/services/localStorageService.test.ts
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { savePatientProfile, loadPatientProfile, saveEpisode, loadEpisodes } from './localStorageService';
// FIX: The file now exists, so this import will work.
import { PatientProfile, Episode } from '../../packages/types/index';

describe('localStorageService', () => {
  // Mock localStorage
  const localStorageMock = (() => {
    let store: { [key: string]: string } = {};
    return {
      getItem: (key: string) => store[key] || null,
      setItem: (key: string, value: string) => {
        store[key] = value.toString();
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      },
    };
  })();

  Object.defineProperty(window, 'localStorage', {
    value: localStorageMock,
  });

  beforeEach(() => {
    localStorageMock.clear();
    vi.spyOn(console, 'error').mockImplementation(() => {}); // Suppress console.error for testing error cases
  });

  describe('Patient Profile', () => {
    it('should save and load a patient profile', () => {
      const profile: PatientProfile = { name: 'John Doe', age: '30' };
      savePatientProfile(profile);
      const loadedProfile = loadPatientProfile();
      expect(loadedProfile).toEqual(profile);
    });

    it('should return null if no profile is saved', () => {
      const loadedProfile = loadPatientProfile();
      expect(loadedProfile).toBeNull();
    });

    it('should handle JSON parsing errors gracefully when loading', () => {
      localStorageMock.setItem('primaryCareAssistantProfile', 'invalid-json');
      const profile = loadPatientProfile();
      expect(profile).toBeNull();
      expect(console.error).toHaveBeenCalled();
    });
  });

  describe('Episodes', () => {
    it('should save a new episode to an empty list', () => {
      const episode: Episode = { id: '1', date: '2023-01-01', initialSymptomsSummary: 'Headache', provisionalDiagnosisSummary: 'Migraine', patientName: 'John' };
      saveEpisode(episode);
      const episodes = loadEpisodes();
      expect(episodes).toHaveLength(1);
      expect(episodes[0]).toEqual(episode);
    });

    it('should add a new episode to the beginning of an existing list', () => {
      const initialEpisode: Episode = { id: '1', date: '2023-01-01', initialSymptomsSummary: 'Fever', provisionalDiagnosisSummary: 'Flu', patientName: 'John' };
      saveEpisode(initialEpisode);

      const newEpisode: Episode = { id: '2', date: '2023-01-02', initialSymptomsSummary: 'Cough', provisionalDiagnosisSummary: 'Cold', patientName: 'John' };
      saveEpisode(newEpisode);

      const episodes = loadEpisodes();
      expect(episodes).toHaveLength(2);
      expect(episodes[0].id).toBe('2');
      expect(episodes[1].id).toBe('1');
    });

    it('should clear all episodes when clearAll is true', () => {
      const episode: Episode = { id: '1', date: '2023-01-01', initialSymptomsSummary: 'Headache', provisionalDiagnosisSummary: 'Migraine', patientName: 'John' };
      saveEpisode(episode);
      let episodes = loadEpisodes();
      expect(episodes).toHaveLength(1);

      saveEpisode(null, true);
      episodes = loadEpisodes();
      expect(episodes).toHaveLength(0);
    });

     it('should return an empty array if no episodes are saved', () => {
      const episodes = loadEpisodes();
      expect(episodes).toEqual([]);
    });

    it('should handle JSON parsing errors gracefully when loading episodes', () => {
        localStorageMock.setItem('primaryCareAssistantEpisodes', 'not-an-array');
        const episodes = loadEpisodes();
        expect(episodes).toEqual([]);
        expect(console.error).toHaveBeenCalled();
    });
  });
});