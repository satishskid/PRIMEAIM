// FIX: Changed 'create' to be a named import for Zustand v4+.
import { create } from 'zustand';
// FIX: Added createJSONStorage for persist middleware.
import { devtools, persist, createJSONStorage } from 'zustand/middleware';
import {
    PatientProfile,
    ProvisionalDiagnosis,
    Clinic,
    Appointment,
    Prescription,
    Episode,
    ChatMessage,
    Task,
    MarketplaceApplication,
} from '../../packages/types';
import * as storage from '../services/localStorageService';
import { v4 as uuidv4 } from 'uuid';

export enum AppStage {
    API_KEY_CHECK = 'API_KEY_CHECK',
    WELCOME = 'WELCOME',
    PATIENT_PROFILE = 'PATIENT_PROFILE',
    SYMPTOM_INPUT = 'SYMPTOM_INPUT',
    CLINIC_SELECTION = 'CLINIC_SELECTION',
    BOOKING = 'BOOKING',
    DOCTOR_PATIENT_VIEW = 'DOCTOR_PATIENT_VIEW',
    PHARMACY_ORDER = 'PHARMACY_ORDER',
    LAB_ORDER = 'LAB_ORDER',
    INTERACTION_HISTORY = 'INTERACTION_HISTORY',
    MARKETPLACE_WELCOME = 'MARKETPLACE_WELCOME',
    MARKETPLACE_ONBOARDING = 'MARKETPLACE_ONBOARDING',
    MARKETPLACE_CONFIRMATION = 'MARKETPLACE_CONFIRMATION',
    ADMIN_LOGIN = 'ADMIN_LOGIN',
    ADMIN_DASHBOARD = 'ADMIN_DASHBOARD',
}

interface AppState {
    // Core state
    currentStage: AppStage;
    stageHistory: AppStage[];

    // Auth state
    authToken: string | null;
    isAdmin: boolean;

    // Patient journey state
    patientProfile: PatientProfile | null;
    patientSymptoms: string;
    chatHistory: ChatMessage[];
    provisionalDiagnosis: ProvisionalDiagnosis | null;
    clinic: Clinic | null;
    appointment: Appointment | null;
    prescription: Prescription | null;

    // History and Tasks
    episodes: Episode[];
    tasks: Task[];
    
    // Marketplace state
    lastProviderApplication: MarketplaceApplication | null;

    // Actions
    goToStage: (stage: AppStage) => void;
    goBack: () => void;

    // Auth actions
    setAuth: (token: string | null, isAdmin: boolean) => void;
    logout: () => void;
    
    // Patient flow actions
    goToWelcome: () => void;
    startSymptomChecker: () => void;
    setPatientProfile: (profile: PatientProfile) => void;
    goToSymptomInput: () => void;
    addMessage: (message: ChatMessage) => void;
    setChatHistory: (history: ChatMessage[]) => void;
    setProvisionalDiagnosis: (diagnosis: ProvisionalDiagnosis) => void;
    goToClinicSelection: () => void;
    setClinic: (clinic: Clinic) => void;
    goToBooking: () => void;
    setAppointmentDateTime: (dateTime: string) => void;
    goToDoctorPatientView: () => void;
    setPrescription: (prescription: Prescription) => void;
    goToPharmacyOrder: () => void;
    resetEpisode: () => void;

    // History actions
    viewHistory: () => void;
    clearHistory: () => void;

    // Marketplace flow actions
    goToMarketplaceWelcome: () => void;
    startProviderOnboarding: () => void;
    goToMarketplaceConfirmation: () => void;
    setLastProviderApplication: (app: MarketplaceApplication) => void;

    // Admin flow actions
    goToAdmin: () => void;
    
    // Task actions
    addTask: (task: Omit<Task, 'id'>) => void;
    updateTask: (task: Task) => void;
    deleteTask: (id: string) => void;
}

export const useAppStore = create<AppState>()(
    devtools(
        persist(
            (set, get) => ({
                currentStage: AppStage.API_KEY_CHECK,
                stageHistory: [AppStage.API_KEY_CHECK],
                authToken: null,
                isAdmin: false,
                patientProfile: null,
                patientSymptoms: '',
                chatHistory: [],
                provisionalDiagnosis: null,
                clinic: null,
                appointment: null,
                prescription: null,
                episodes: storage.loadEpisodes(),
                tasks: storage.loadTasks(),
                lastProviderApplication: null,

                goToStage: (stage) => set(state => ({
                    currentStage: stage,
                    stageHistory: [...state.stageHistory, stage]
                })),

                goBack: () => set(state => {
                    if (state.stageHistory.length <= 1) return {};
                    const newHistory = [...state.stageHistory];
                    newHistory.pop();
                    return {
                        currentStage: newHistory[newHistory.length - 1],
                        stageHistory: newHistory
                    };
                }),
                
                setAuth: (token, isAdmin) => set({ authToken: token, isAdmin }),

                logout: () => {
                    localStorage.removeItem('authToken');
                    set({ 
                        authToken: null, 
                        isAdmin: false, 
                        currentStage: AppStage.WELCOME, 
                        stageHistory: [AppStage.WELCOME] 
                    });
                },

                goToWelcome: () => get().goToStage(AppStage.WELCOME),
                
                startSymptomChecker: () => get().goToStage(AppStage.PATIENT_PROFILE),

                setPatientProfile: (profile) => {
                    set({ patientProfile: profile });
                    storage.savePatientProfile(profile);
                },

                goToSymptomInput: () => get().goToStage(AppStage.SYMPTOM_INPUT),
                
                addMessage: (message) => set(state => {
                    const newHistory = [...state.chatHistory, message];
                    if (state.chatHistory.length === 0 && message.sender === 'user') {
                        return { chatHistory: newHistory, patientSymptoms: message.text };
                    }
                    return { chatHistory: newHistory };
                }),

                setChatHistory: (history) => set({ chatHistory: history }),

                setProvisionalDiagnosis: (diagnosis) => set({ provisionalDiagnosis: diagnosis }),

                goToClinicSelection: () => get().goToStage(AppStage.CLINIC_SELECTION),

                setClinic: (clinic) => set({ clinic }),

                goToBooking: () => {
                    const { patientProfile, patientSymptoms, provisionalDiagnosis, clinic } = get();
                    if (clinic) {
                        set({
                            appointment: {
                                patientProfile: patientProfile || undefined,
                                patientSymptoms,
                                provisionalDiagnosis: provisionalDiagnosis || undefined,
                                clinic,
                                dateTime: '',
                            }
                        });
                        get().goToStage(AppStage.BOOKING);
                    }
                },

                setAppointmentDateTime: (dateTime) => set(state => ({
                    appointment: state.appointment ? { ...state.appointment, dateTime } : null
                })),

                goToDoctorPatientView: () => get().goToStage(AppStage.DOCTOR_PATIENT_VIEW),

                setPrescription: (prescription) => set(state => ({
                    prescription,
                    appointment: state.appointment ? { ...state.appointment, prescription } : null,
                })),

                goToPharmacyOrder: () => get().goToStage(AppStage.PHARMACY_ORDER),
                
                resetEpisode: () => {
                    const { appointment, patientSymptoms, provisionalDiagnosis, prescription } = get();
                    if (appointment) {
                        const newEpisode: Episode = {
                            id: uuidv4(),
                            date: new Date().toISOString(),
                            patientName: appointment.patientProfile?.name,
                            initialSymptomsSummary: patientSymptoms,
                            provisionalDiagnosisSummary: provisionalDiagnosis?.condition || 'N/A',
                            clinicName: appointment.clinic?.name,
                            prescriptionSummary: prescription?.medications.map(m => m.name).join(', ') || 'N/A',
                        };
                        storage.saveEpisode(newEpisode);
                    }
                    set({
                        patientSymptoms: '',
                        chatHistory: [],
                        provisionalDiagnosis: null,
                        clinic: null,
                        appointment: null,
                        prescription: null,
                        currentStage: AppStage.WELCOME,
                        stageHistory: [AppStage.WELCOME],
                        episodes: storage.loadEpisodes(),
                    });
                },

                viewHistory: () => get().goToStage(AppStage.INTERACTION_HISTORY),

                clearHistory: () => {
                    storage.saveEpisode(null, true);
                    set({ episodes: [] });
                },

                goToMarketplaceWelcome: () => get().goToStage(AppStage.MARKETPLACE_WELCOME),
                startProviderOnboarding: () => get().goToStage(AppStage.MARKETPLACE_ONBOARDING),
                goToMarketplaceConfirmation: () => get().goToStage(AppStage.MARKETPLACE_CONFIRMATION),
                setLastProviderApplication: (app) => set({ lastProviderApplication: app }),

                goToAdmin: () => get().goToStage(AppStage.ADMIN_LOGIN),
                
                addTask: (task) => set(state => {
                    const newTask = { ...task, id: uuidv4() };
                    const newTasks = [...state.tasks, newTask];
                    storage.saveTasks(newTasks);
                    return { tasks: newTasks };
                }),
                
                updateTask: (updatedTask) => set(state => {
                    const newTasks = state.tasks.map(task => task.id === updatedTask.id ? updatedTask : task);
                    storage.saveTasks(newTasks);
                    return { tasks: newTasks };
                }),
                
                deleteTask: (id) => set(state => {
                    const newTasks = state.tasks.filter(task => task.id !== id);
                    storage.saveTasks(newTasks);
                    return { tasks: newTasks };
                }),
            }),
            {
                name: 'primary-care-assistant-storage',
                storage: createJSONStorage(() => localStorage),
                partialize: (state) => ({
                    patientProfile: state.patientProfile,
                    authToken: state.authToken,
                    isAdmin: state.isAdmin,
                }),
            }
        )
    )
);

// Load profile on initial load
const initialProfile = storage.loadPatientProfile();
if (initialProfile) {
    useAppStore.setState({ patientProfile: initialProfile });
}

// Rehydrate auth token from localStorage on initial load
const token = localStorage.getItem('authToken');
if (token) {
    // A simple rehydration. In a real app, you'd verify the token's expiry.
    useAppStore.setState({ authToken: token, isAdmin: useAppStore.getState().isAdmin });
}
