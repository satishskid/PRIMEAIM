// e2e/app.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Primary Care Assistant E2E Flow', () => {
  
  test.beforeEach(async ({ page }) => {
    // Clear local storage before each test to ensure a clean state
    await page.goto('/');
    await page.evaluate(() => window.localStorage.clear());
  });

  test('should load the welcome page and navigate to patient profile', async ({ page }) => {
    // 1. Start at the root page.
    await page.goto('/');

    // 2. Expect the main heading to be visible.
    await expect(page.getByRole('heading', { name: 'Primary Care Assistant' })).toBeVisible();

    // 3. Find the "Start Symptom Checker" button and click it.
    const startButton = page.getByRole('button', { name: 'Start Symptom Checker' });
    await expect(startButton).toBeVisible();
    await startButton.click();

    // 4. Expect to be on the patient profile page.
    // The URL should not change in this SPA, so we check for content.
    await expect(page.getByRole('heading', { name: 'Personalizing Your Assessment' })).toBeVisible();

    // 5. Verify a field from the profile form is present.
    await expect(page.getByLabel('Full Name')).toBeVisible();
  });

  test('should show validation error on empty profile submission', async ({ page }) => {
    // 1. Navigate to the profile page first.
    await page.goto('/');
    await page.getByRole('button', { name: 'Start Symptom Checker' }).click();
    await expect(page.getByRole('heading', { name: 'Personalizing Your Assessment' })).toBeVisible();

    // 2. Click the submit button without filling out the form.
    await page.getByRole('button', { name: 'Continue to Symptom Checker' }).click();

    // 3. Expect to see a validation error message.
    await expect(page.getByText('Name is required to personalize your experience.')).toBeVisible();
  });

});